import { useState } from 'react';
import { initializeDemoUser, getCurrentUser, setCurrentUser } from './store';
import { AuthPage } from './components/AuthPage';
import { Sidebar } from './components/Sidebar';
import { Dashboard } from './components/Dashboard';
import { TransactionsPage } from './components/TransactionsPage';
import { BudgetPage } from './components/BudgetPage';
import { AnalyticsPage } from './components/AnalyticsPage';
import { SavingsPage } from './components/SavingsPage';
import { RecurringPage } from './components/RecurringPage';
import { TransactionModal } from './components/TransactionModal';
import type { User, NavSection } from './types';

initializeDemoUser();

export default function App() {
  const [user, setUser] = useState<User | null>(() => getCurrentUser());
  const [section, setSection] = useState<NavSection>('dashboard');
  const [refreshKey, setRefreshKey] = useState(0);
  const [showAddModal, setShowAddModal] = useState(false);

  function handleAuth(u: User) {
    setUser(u);
    setSection('dashboard');
  }

  function handleLogout() {
    setCurrentUser(null);
    setUser(null);
    setSection('dashboard');
  }

  function refresh() {
    setRefreshKey(k => k + 1);
  }

  if (!user) {
    return <AuthPage onAuth={handleAuth} />;
  }

  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar user={user} current={section} onChange={setSection} onLogout={handleLogout} />

      {/* Main content — offset on mobile for fixed top nav, no offset on desktop */}
      <main className="flex-1 overflow-y-auto pt-14 lg:pt-0">
        {section === 'dashboard' && (
          <Dashboard
            user={user}
            refreshKey={refreshKey}
            onNavigate={setSection}
            onAddTransaction={() => setShowAddModal(true)}
          />
        )}
        {section === 'transactions' && (
          <TransactionsPage user={user} refreshKey={refreshKey} onRefresh={refresh} />
        )}
        {section === 'budget' && (
          <BudgetPage user={user} refreshKey={refreshKey} onRefresh={refresh} />
        )}
        {section === 'analytics' && (
          <AnalyticsPage user={user} refreshKey={refreshKey} />
        )}
        {section === 'savings' && (
          <SavingsPage user={user} refreshKey={refreshKey} onRefresh={refresh} />
        )}
        {section === 'recurring' && (
          <RecurringPage user={user} refreshKey={refreshKey} onRefresh={refresh} />
        )}
      </main>

      {showAddModal && (
        <TransactionModal
          user={user}
          onClose={() => setShowAddModal(false)}
          onSave={() => { setShowAddModal(false); refresh(); }}
        />
      )}
    </div>
  );
}
