import { useState } from 'react';
import {
  PieChart, Pie, Cell, Tooltip, ResponsiveContainer, Legend,
  BarChart, Bar, XAxis, YAxis, CartesianGrid,
  LineChart, Line, Area, AreaChart,
} from 'recharts';
import { getTransactions } from '../store';
import { CATEGORY_COLORS, CATEGORY_ICONS, formatCurrency } from '../types';
import type { User } from '../types';

interface Props {
  user: User;
  refreshKey: number;
}

const MONTH_LABELS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

function SectionCard({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-xl p-5" style={{ background: 'white', border: '1px solid rgba(0,0,0,0.06)', boxShadow: '0 1px 3px rgba(0,0,0,0.04)' }}>
      <h3 style={{ fontWeight: 700, fontSize: '0.95rem', color: '#0f172a', marginBottom: '16px' }}>{title}</h3>
      {children}
    </div>
  );
}

const CustomTooltip = ({ active, payload, label }: { active?: boolean; payload?: Array<{ value: number; name: string; color?: string }>; label?: string }) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="rounded-xl px-3 py-2.5" style={{ background: 'white', border: '1px solid rgba(0,0,0,0.1)', boxShadow: '0 8px 24px rgba(0,0,0,0.12)', fontSize: '0.8rem' }}>
      {label && <div style={{ fontWeight: 700, color: '#0f172a', marginBottom: 4 }}>{label}</div>}
      {payload.map((p, i) => (
        <div key={i} className="flex items-center gap-2">
          <span style={{ width: 8, height: 8, borderRadius: '50%', background: p.color, display: 'inline-block' }} />
          <span style={{ color: '#64748b' }}>{p.name}:</span>
          <span style={{ fontWeight: 600, color: '#0f172a' }}>{formatCurrency(p.value)}</span>
        </div>
      ))}
    </div>
  );
};

export function AnalyticsPage({ user, refreshKey: _rk }: Props) {
  const transactions = getTransactions(user.id);
  const now = new Date();
  const [selectedYear, setSelectedYear] = useState(now.getFullYear());

  // Pie chart data – current month category breakdown
  const currentMonthStart = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-01`;
  const currentMonthEnd = new Date(now.getFullYear(), now.getMonth() + 1, 0).toISOString().split('T')[0];
  const monthExpenses = transactions.filter(t => t.type === 'expense' && t.date >= currentMonthStart && t.date <= currentMonthEnd);
  const catMap: Record<string, number> = {};
  monthExpenses.forEach(t => { catMap[t.category] = (catMap[t.category] || 0) + t.amount; });
  const pieData = Object.entries(catMap)
    .sort((a, b) => b[1] - a[1])
    .map(([name, value]) => ({ name, value, color: CATEGORY_COLORS[name] || '#94a3b8' }));

  // Bar chart – monthly income vs expense for selected year
  const barData = MONTH_LABELS.map((label, idx) => {
    const month = String(idx + 1).padStart(2, '0');
    const prefix = `${selectedYear}-${month}`;
    const mTxs = transactions.filter(t => t.date.startsWith(prefix));
    const income = mTxs.filter(t => t.type === 'income').reduce((s, t) => s + t.amount, 0);
    const expense = mTxs.filter(t => t.type === 'expense').reduce((s, t) => s + t.amount, 0);
    return { label, income, expense };
  });

  // Line chart – daily spending trend for current month
  const daysInMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate();
  let cumulative = 0;
  const lineData = Array.from({ length: Math.min(daysInMonth, now.getDate()) }, (_, i) => {
    const day = String(i + 1).padStart(2, '0');
    const dateStr = `${currentMonthStart.slice(0, 7)}-${day}`;
    const dayExpense = transactions.filter(t => t.type === 'expense' && t.date === dateStr).reduce((s, t) => s + t.amount, 0);
    cumulative += dayExpense;
    return { day: i + 1, daily: dayExpense, cumulative };
  });

  const totalMonthExpense = monthExpenses.reduce((s, t) => s + t.amount, 0);
  const totalMonthIncome = transactions.filter(t => t.type === 'income' && t.date >= currentMonthStart && t.date <= currentMonthEnd).reduce((s, t) => s + t.amount, 0);

  const years = [...new Set(transactions.map(t => parseInt(t.date.slice(0, 4))))].sort((a, b) => b - a);
  if (!years.includes(selectedYear) && years.length) years.push(selectedYear);

  return (
    <div className="p-6 space-y-6 max-w-5xl">
      <div>
        <h2 style={{ fontWeight: 700, fontSize: '1.4rem', color: '#0f172a', letterSpacing: '-0.02em' }}>Analytics</h2>
        <p style={{ color: '#64748b', fontSize: '0.875rem', marginTop: '2px' }}>Visual breakdown of your spending patterns</p>
      </div>

      {/* Month summary strip */}
      <div className="grid grid-cols-3 gap-3">
        {[
          { label: 'Month Income', value: formatCurrency(totalMonthIncome), color: '#10b981', bg: '#f0fdf4' },
          { label: 'Month Expense', value: formatCurrency(totalMonthExpense), color: '#ef4444', bg: '#fef2f2' },
          { label: 'Net Savings', value: formatCurrency(totalMonthIncome - totalMonthExpense), color: '#4f46e5', bg: '#eef2ff' },
        ].map(item => (
          <div key={item.label} className="rounded-xl p-4 text-center" style={{ background: item.bg }}>
            <div style={{ fontSize: '1.25rem', fontWeight: 700, color: item.color, letterSpacing: '-0.02em' }}>{item.value}</div>
            <div style={{ fontSize: '0.75rem', color: '#64748b', marginTop: '2px' }}>{item.label}</div>
          </div>
        ))}
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Pie chart */}
        <SectionCard title={`Category Breakdown — ${new Date().toLocaleString('en-IN', { month: 'long' })}`}>
          {pieData.length === 0 ? (
            <div className="h-48 flex items-center justify-center">
              <p style={{ color: '#94a3b8', fontSize: '0.875rem' }}>No expenses this month</p>
            </div>
          ) : (
            <>
              <ResponsiveContainer width="100%" height={220}>
                <PieChart>
                  <Pie
                    data={pieData}
                    cx="50%"
                    cy="50%"
                    innerRadius={55}
                    outerRadius={90}
                    paddingAngle={3}
                    dataKey="value"
                  >
                    {pieData.map((entry, i) => (
                      <Cell key={i} fill={entry.color} strokeWidth={0} />
                    ))}
                  </Pie>
                  <Tooltip content={<CustomTooltip />} />
                </PieChart>
              </ResponsiveContainer>
              <div className="space-y-1.5 mt-2">
                {pieData.slice(0, 5).map(d => (
                  <div key={d.name} className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ background: d.color }} />
                      <span style={{ fontSize: '0.8rem', color: '#64748b' }}>{CATEGORY_ICONS[d.name]} {d.name}</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <span style={{ fontSize: '0.75rem', color: '#94a3b8' }}>{totalMonthExpense > 0 ? Math.round((d.value / totalMonthExpense) * 100) : 0}%</span>
                      <span style={{ fontSize: '0.8rem', fontWeight: 600, color: '#0f172a' }}>{formatCurrency(d.value)}</span>
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}
        </SectionCard>

        {/* Bar chart – monthly comparison */}
        <SectionCard title={`Monthly Income vs Expenses`}>
          <div className="flex items-center gap-2 mb-3">
            <select
              value={selectedYear}
              onChange={e => setSelectedYear(Number(e.target.value))}
              style={{ background: '#f8fafc', border: '1.5px solid #e2e8f0', borderRadius: '0.5rem', padding: '4px 8px', fontSize: '0.8rem', color: '#0f172a', outline: 'none' }}
            >
              {(years.length ? years : [now.getFullYear()]).map(y => <option key={y} value={y}>{y}</option>)}
            </select>
          </div>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={barData} barCategoryGap="30%" barGap={4}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
              <XAxis dataKey="label" tick={{ fontSize: 11, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: '#94a3b8' }} axisLine={false} tickLine={false} tickFormatter={v => `₹${(v / 1000).toFixed(0)}k`} />
              <Tooltip content={<CustomTooltip />} />
              <Bar dataKey="income" fill="#10b981" name="Income" radius={[4, 4, 0, 0]} />
              <Bar dataKey="expense" fill="#ef4444" name="Expense" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
          <div className="flex items-center gap-4 mt-2">
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-sm" style={{ background: '#10b981', display: 'inline-block' }} />
              <span style={{ fontSize: '0.75rem', color: '#64748b' }}>Income</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-sm" style={{ background: '#ef4444', display: 'inline-block' }} />
              <span style={{ fontSize: '0.75rem', color: '#64748b' }}>Expenses</span>
            </div>
          </div>
        </SectionCard>
      </div>

      {/* Area/Line chart – daily spending trend */}
      <SectionCard title={`Daily Spending Trend — ${new Date().toLocaleString('en-IN', { month: 'long', year: 'numeric' })}`}>
        {lineData.every(d => d.daily === 0) ? (
          <div className="h-48 flex items-center justify-center">
            <p style={{ color: '#94a3b8', fontSize: '0.875rem' }}>No spending data for this month</p>
          </div>
        ) : (
          <ResponsiveContainer width="100%" height={250}>
            <AreaChart data={lineData}>
              <defs>
                <linearGradient id="dailyGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#4f46e5" stopOpacity={0.15} />
                  <stop offset="95%" stopColor="#4f46e5" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="cumGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#10b981" stopOpacity={0.15} />
                  <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
              <XAxis dataKey="day" tick={{ fontSize: 11, fill: '#94a3b8' }} axisLine={false} tickLine={false} label={{ value: 'Day', position: 'insideBottom', offset: -2, style: { fontSize: 11, fill: '#94a3b8' } }} />
              <YAxis tick={{ fontSize: 11, fill: '#94a3b8' }} axisLine={false} tickLine={false} tickFormatter={v => `₹${(v / 1000).toFixed(0)}k`} />
              <Tooltip content={<CustomTooltip />} />
              <Area type="monotone" dataKey="daily" stroke="#4f46e5" strokeWidth={2} fill="url(#dailyGradient)" name="Daily" dot={false} />
              <Area type="monotone" dataKey="cumulative" stroke="#10b981" strokeWidth={2} fill="url(#cumGradient)" name="Cumulative" dot={false} strokeDasharray="5 3" />
            </AreaChart>
          </ResponsiveContainer>
        )}
        <div className="flex items-center gap-4 mt-2">
          <div className="flex items-center gap-1.5">
            <span className="w-6 h-0.5 inline-block" style={{ background: '#4f46e5' }} />
            <span style={{ fontSize: '0.75rem', color: '#64748b' }}>Daily spending</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-6 h-0.5 inline-block" style={{ background: '#10b981', borderTop: '2px dashed #10b981' }} />
            <span style={{ fontSize: '0.75rem', color: '#64748b' }}>Cumulative total</span>
          </div>
        </div>
      </SectionCard>
    </div>
  );
}
