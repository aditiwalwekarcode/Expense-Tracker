import { useState } from 'react';
import { Eye, EyeOff, TrendingUp, Lock, Mail, User } from 'lucide-react';
import { registerUser, loginUser, setCurrentUser } from '../store';
import type { User as UserType } from '../types';

interface Props {
  onAuth: (user: UserType) => void;
}

export function AuthPage({ onAuth }: Props) {
  const [mode, setMode] = useState<'login' | 'signup'>('login');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    setLoading(true);

    setTimeout(() => {
      if (mode === 'signup') {
        if (!name.trim()) { setError('Please enter your name.'); setLoading(false); return; }
        if (password.length < 6) { setError('Password must be at least 6 characters.'); setLoading(false); return; }
        const result = registerUser(name.trim(), email, password);
        if (typeof result === 'string') { setError(result); setLoading(false); return; }
        setCurrentUser(result);
        onAuth(result);
      } else {
        const result = loginUser(email, password);
        if (typeof result === 'string') { setError(result); setLoading(false); return; }
        setCurrentUser(result);
        onAuth(result);
      }
      setLoading(false);
    }, 400);
  }

  function fillDemo() {
    setEmail('demo@example.com');
    setPassword('demo123');
    setMode('login');
    setError('');
  }

  return (
    <div className="min-h-screen flex" style={{ background: 'linear-gradient(135deg, #0f172a 0%, #1e1b4b 50%, #0f172a 100%)' }}>
      {/* Left panel */}
      <div className="hidden lg:flex lg:w-1/2 flex-col justify-center px-16 py-12">
        <div className="flex items-center gap-3 mb-12">
          <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: '#4f46e5' }}>
            <TrendingUp size={22} color="white" />
          </div>
          <span className="text-white" style={{ fontSize: '1.25rem', fontWeight: 700, letterSpacing: '-0.02em' }}>FinTrack</span>
        </div>
        <h1 className="text-white mb-4" style={{ fontSize: '2.5rem', fontWeight: 700, lineHeight: 1.2, letterSpacing: '-0.03em' }}>
          Take control of your<br />finances today.
        </h1>
        <p style={{ color: '#94a3b8', lineHeight: 1.7 }}>
          Track expenses, set budgets, achieve savings goals, and get powerful insights into your spending habits.
        </p>
        <div className="mt-12 grid grid-cols-2 gap-4">
          {[
            { icon: '📊', label: 'Smart Analytics', desc: 'Visual charts & trends' },
            { icon: '🎯', label: 'Budget Goals', desc: 'Category-wise limits' },
            { icon: '💰', label: 'Savings Tracker', desc: 'Progress to goals' },
            { icon: '🔄', label: 'Recurring Bills', desc: 'Auto-track subscriptions' },
          ].map(f => (
            <div key={f.label} className="rounded-xl p-4" style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.08)' }}>
              <div className="mb-2" style={{ fontSize: '1.5rem' }}>{f.icon}</div>
              <div className="text-white" style={{ fontWeight: 600, fontSize: '0.875rem' }}>{f.label}</div>
              <div style={{ color: '#64748b', fontSize: '0.75rem', marginTop: '2px' }}>{f.desc}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Right panel */}
      <div className="flex-1 flex items-center justify-center px-6 py-12">
        <div className="w-full max-w-md">
          {/* Mobile logo */}
          <div className="flex items-center gap-2 mb-8 lg:hidden">
            <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: '#4f46e5' }}>
              <TrendingUp size={16} color="white" />
            </div>
            <span className="text-white" style={{ fontWeight: 700, fontSize: '1.1rem' }}>FinTrack</span>
          </div>

          <div className="rounded-2xl p-8" style={{ background: 'rgba(255,255,255,0.97)', boxShadow: '0 25px 60px rgba(0,0,0,0.4)' }}>
            <div className="mb-6">
              <h2 className="text-foreground" style={{ fontWeight: 700, fontSize: '1.5rem', letterSpacing: '-0.02em' }}>
                {mode === 'login' ? 'Welcome back' : 'Create account'}
              </h2>
              <p style={{ color: '#64748b', fontSize: '0.875rem', marginTop: '4px' }}>
                {mode === 'login' ? 'Sign in to your account' : 'Start tracking your finances'}
              </p>
            </div>

            {/* Demo banner */}
            <button
              onClick={fillDemo}
              className="w-full mb-4 rounded-xl py-2.5 px-4 text-left transition-colors"
              style={{ background: '#eef2ff', border: '1px dashed #818cf8' }}
            >
              <span style={{ fontSize: '0.75rem', color: '#4f46e5', fontWeight: 600 }}>✨ Try Demo Account</span>
              <span style={{ fontSize: '0.75rem', color: '#6366f1', marginLeft: 8 }}>demo@example.com / demo123</span>
            </button>

            <form onSubmit={handleSubmit} className="space-y-4">
              {mode === 'signup' && (
                <div>
                  <label style={{ fontSize: '0.875rem', fontWeight: 600, color: '#374151' }}>Full Name</label>
                  <div className="relative mt-1">
                    <User size={16} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: '#9ca3af' }} />
                    <input
                      type="text"
                      value={name}
                      onChange={e => setName(e.target.value)}
                      placeholder="Arjun Sharma"
                      required
                      className="w-full pl-10 pr-4 py-2.5 rounded-xl outline-none transition-all"
                      style={{ background: '#f8fafc', border: '1.5px solid #e2e8f0', fontSize: '0.9rem' }}
                      onFocus={e => (e.target.style.borderColor = '#4f46e5')}
                      onBlur={e => (e.target.style.borderColor = '#e2e8f0')}
                    />
                  </div>
                </div>
              )}

              <div>
                <label style={{ fontSize: '0.875rem', fontWeight: 600, color: '#374151' }}>Email Address</label>
                <div className="relative mt-1">
                  <Mail size={16} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: '#9ca3af' }} />
                  <input
                    type="email"
                    value={email}
                    onChange={e => setEmail(e.target.value)}
                    placeholder="you@example.com"
                    required
                    className="w-full pl-10 pr-4 py-2.5 rounded-xl outline-none transition-all"
                    style={{ background: '#f8fafc', border: '1.5px solid #e2e8f0', fontSize: '0.9rem' }}
                    onFocus={e => (e.target.style.borderColor = '#4f46e5')}
                    onBlur={e => (e.target.style.borderColor = '#e2e8f0')}
                  />
                </div>
              </div>

              <div>
                <label style={{ fontSize: '0.875rem', fontWeight: 600, color: '#374151' }}>Password</label>
                <div className="relative mt-1">
                  <Lock size={16} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: '#9ca3af' }} />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={e => setPassword(e.target.value)}
                    placeholder={mode === 'signup' ? 'At least 6 characters' : '••••••••'}
                    required
                    className="w-full pl-10 pr-11 py-2.5 rounded-xl outline-none transition-all"
                    style={{ background: '#f8fafc', border: '1.5px solid #e2e8f0', fontSize: '0.9rem' }}
                    onFocus={e => (e.target.style.borderColor = '#4f46e5')}
                    onBlur={e => (e.target.style.borderColor = '#e2e8f0')}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(v => !v)}
                    className="absolute right-3 top-1/2 -translate-y-1/2"
                    style={{ color: '#9ca3af' }}
                  >
                    {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                  </button>
                </div>
              </div>

              {error && (
                <div className="rounded-lg px-3 py-2.5" style={{ background: '#fef2f2', border: '1px solid #fecaca' }}>
                  <p style={{ color: '#ef4444', fontSize: '0.8rem', fontWeight: 500 }}>{error}</p>
                </div>
              )}

              <button
                type="submit"
                disabled={loading}
                className="w-full py-2.5 rounded-xl transition-all"
                style={{ background: loading ? '#a5b4fc' : '#4f46e5', color: 'white', fontWeight: 600, fontSize: '0.95rem', cursor: loading ? 'not-allowed' : 'pointer' }}
              >
                {loading ? 'Please wait…' : mode === 'login' ? 'Sign In' : 'Create Account'}
              </button>
            </form>

            <p className="mt-5 text-center" style={{ fontSize: '0.875rem', color: '#64748b' }}>
              {mode === 'login' ? "Don't have an account? " : 'Already have an account? '}
              <button
                onClick={() => { setMode(mode === 'login' ? 'signup' : 'login'); setError(''); }}
                style={{ color: '#4f46e5', fontWeight: 600 }}
              >
                {mode === 'login' ? 'Sign up' : 'Sign in'}
              </button>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
