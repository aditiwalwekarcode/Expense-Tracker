import { useState } from 'react';
import { Save, Edit2, Check } from 'lucide-react';
import { getBudget, saveBudget, getTransactions } from '../store';
import { formatCurrency, getCurrentMonthRange, EXPENSE_CATEGORIES, CATEGORY_ICONS, CATEGORY_COLORS } from '../types';
import type { User } from '../types';

interface Props {
  user: User;
  refreshKey: number;
  onRefresh: () => void;
}

export function BudgetPage({ user, refreshKey: _rk, onRefresh }: Props) {
  const budget = getBudget(user.id);
  const transactions = getTransactions(user.id);
  const { start, end } = getCurrentMonthRange();

  const monthExpenses = transactions.filter(t => t.type === 'expense' && t.date >= start && t.date <= end);

  // Spending per category this month
  const spent: Record<string, number> = {};
  monthExpenses.forEach(t => { spent[t.category] = (spent[t.category] || 0) + t.amount; });

  const totalSpent = monthExpenses.reduce((s, t) => s + t.amount, 0);

  const [editMonthly, setEditMonthly] = useState(false);
  const [monthlyInput, setMonthlyInput] = useState(String(budget.monthly || ''));
  const [catInputs, setCatInputs] = useState<Record<string, string>>(
    Object.fromEntries(EXPENSE_CATEGORIES.map(c => [c, String(budget.categories[c] || '')]))
  );
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  function handleSave() {
    setSaving(true);
    const newBudget = {
      monthly: parseFloat(monthlyInput) || 0,
      categories: Object.fromEntries(
        EXPENSE_CATEGORIES.map(c => [c, parseFloat(catInputs[c]) || 0])
      ),
    };
    saveBudget(user.id, newBudget);
    onRefresh();
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
    setEditMonthly(false);
  }

  const monthly = parseFloat(monthlyInput) || 0;
  const remaining = monthly - totalSpent;
  const overallPct = monthly > 0 ? Math.min((totalSpent / monthly) * 100, 100) : 0;
  const overallColor = overallPct > 90 ? '#ef4444' : overallPct > 70 ? '#f59e0b' : '#4f46e5';

  const inputStyle: React.CSSProperties = {
    background: '#f8fafc', border: '1.5px solid #e2e8f0', borderRadius: '0.5rem',
    padding: '0.4rem 0.6rem', fontSize: '0.85rem', color: '#0f172a', outline: 'none',
  };

  return (
    <div className="p-6 space-y-6 max-w-3xl">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 style={{ fontWeight: 700, fontSize: '1.4rem', color: '#0f172a', letterSpacing: '-0.02em' }}>Budget Planner</h2>
          <p style={{ color: '#64748b', fontSize: '0.875rem', marginTop: '2px' }}>
            {new Date().toLocaleString('en-IN', { month: 'long', year: 'numeric' })} budget
          </p>
        </div>
        <button
          onClick={handleSave}
          disabled={saving}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl transition-all"
          style={{ background: saved ? '#10b981' : '#4f46e5', color: 'white', fontWeight: 600, fontSize: '0.875rem', boxShadow: '0 4px 12px rgba(79,70,229,0.3)' }}
        >
          {saved ? <><Check size={15} /> Saved!</> : <><Save size={15} /> Save Budget</>}
        </button>
      </div>

      {/* Monthly budget card */}
      <div className="rounded-xl p-6" style={{ background: 'white', border: '1px solid rgba(0,0,0,0.06)', boxShadow: '0 1px 3px rgba(0,0,0,0.04)' }}>
        <div className="flex items-center justify-between mb-4">
          <h3 style={{ fontWeight: 700, fontSize: '1rem', color: '#0f172a' }}>Monthly Budget Overview</h3>
          <button onClick={() => setEditMonthly(v => !v)} style={{ color: '#4f46e5' }}>
            <Edit2 size={15} />
          </button>
        </div>

        <div className="flex items-center gap-6 mb-5 flex-wrap">
          <div>
            <div style={{ fontSize: '0.75rem', color: '#94a3b8', fontWeight: 600 }}>MONTHLY LIMIT</div>
            {editMonthly ? (
              <div className="flex items-center gap-1 mt-1">
                <span style={{ color: '#64748b' }}>₹</span>
                <input
                  type="number"
                  value={monthlyInput}
                  onChange={e => setMonthlyInput(e.target.value)}
                  style={{ ...inputStyle, width: '120px' }}
                  placeholder="0"
                  onFocus={e => (e.target.style.borderColor = '#4f46e5')}
                  onBlur={e => (e.target.style.borderColor = '#e2e8f0')}
                />
              </div>
            ) : (
              <div style={{ fontSize: '1.5rem', fontWeight: 700, color: '#0f172a', letterSpacing: '-0.02em' }}>{formatCurrency(monthly)}</div>
            )}
          </div>
          <div>
            <div style={{ fontSize: '0.75rem', color: '#94a3b8', fontWeight: 600 }}>SPENT SO FAR</div>
            <div style={{ fontSize: '1.5rem', fontWeight: 700, color: '#ef4444', letterSpacing: '-0.02em' }}>{formatCurrency(totalSpent)}</div>
          </div>
          <div>
            <div style={{ fontSize: '0.75rem', color: '#94a3b8', fontWeight: 600 }}>{remaining >= 0 ? 'REMAINING' : 'OVER BY'}</div>
            <div style={{ fontSize: '1.5rem', fontWeight: 700, color: remaining >= 0 ? '#10b981' : '#ef4444', letterSpacing: '-0.02em' }}>{formatCurrency(Math.abs(remaining))}</div>
          </div>
        </div>

        {monthly > 0 && (
          <div>
            <div className="flex justify-between mb-1.5">
              <span style={{ fontSize: '0.8rem', color: '#64748b' }}>{overallPct.toFixed(1)}% used</span>
              <span style={{ fontSize: '0.8rem', color: overallColor, fontWeight: 600 }}>
                {remaining >= 0 ? `${formatCurrency(remaining)} left` : `${formatCurrency(-remaining)} over budget`}
              </span>
            </div>
            <div className="h-3 rounded-full overflow-hidden" style={{ background: '#f1f5f9' }}>
              <div className="h-full rounded-full transition-all" style={{ width: `${overallPct}%`, background: overallColor }} />
            </div>
          </div>
        )}
      </div>

      {/* Category budgets */}
      <div className="rounded-xl p-6" style={{ background: 'white', border: '1px solid rgba(0,0,0,0.06)', boxShadow: '0 1px 3px rgba(0,0,0,0.04)' }}>
        <h3 style={{ fontWeight: 700, fontSize: '1rem', color: '#0f172a', marginBottom: '16px' }}>Category Budgets</h3>
        <div className="space-y-4">
          {EXPENSE_CATEGORIES.map(cat => {
            const catBudget = parseFloat(catInputs[cat]) || 0;
            const catSpent = spent[cat] || 0;
            const catPct = catBudget > 0 ? Math.min((catSpent / catBudget) * 100, 100) : 0;
            const catColor = CATEGORY_COLORS[cat] || '#94a3b8';
            const catOver = catBudget > 0 && catSpent > catBudget;
            const catRem = catBudget - catSpent;

            return (
              <div key={cat} className="p-4 rounded-xl" style={{ background: '#fafafa', border: '1px solid #f1f5f9' }}>
                <div className="flex items-center justify-between gap-3 mb-2.5">
                  <div className="flex items-center gap-2">
                    <span style={{ fontSize: '1.25rem' }}>{CATEGORY_ICONS[cat]}</span>
                    <span style={{ fontWeight: 600, fontSize: '0.875rem', color: '#0f172a' }}>{cat}</span>
                    {catOver && <span className="px-1.5 py-0.5 rounded text-xs" style={{ background: '#fef2f2', color: '#ef4444', fontWeight: 600 }}>Over!</span>}
                  </div>
                  <div className="flex items-center gap-2">
                    <span style={{ fontSize: '0.8rem', color: '#64748b' }}>Spent: {formatCurrency(catSpent)}</span>
                    <span style={{ fontSize: '0.75rem', color: '#cbd5e1' }}>/</span>
                    <div className="flex items-center gap-1">
                      <span style={{ fontSize: '0.75rem', color: '#94a3b8' }}>₹</span>
                      <input
                        type="number"
                        value={catInputs[cat]}
                        onChange={e => setCatInputs(prev => ({ ...prev, [cat]: e.target.value }))}
                        placeholder="No limit"
                        style={{ ...inputStyle, width: '80px', fontSize: '0.8rem' }}
                        onFocus={e => (e.target.style.borderColor = catColor)}
                        onBlur={e => (e.target.style.borderColor = '#e2e8f0')}
                      />
                    </div>
                  </div>
                </div>

                {catBudget > 0 && (
                  <div>
                    <div className="h-2 rounded-full overflow-hidden" style={{ background: '#f1f5f9' }}>
                      <div
                        className="h-full rounded-full transition-all"
                        style={{ width: `${catPct}%`, background: catOver ? '#ef4444' : catColor }}
                      />
                    </div>
                    <div className="flex justify-between mt-1">
                      <span style={{ fontSize: '0.7rem', color: '#94a3b8' }}>{catPct.toFixed(0)}%</span>
                      <span style={{ fontSize: '0.7rem', color: catOver ? '#ef4444' : '#10b981', fontWeight: 600 }}>
                        {catOver ? `₹${Math.abs(catRem).toLocaleString('en-IN')} over` : `₹${catRem.toLocaleString('en-IN')} left`}
                      </span>
                    </div>
                  </div>
                )}
                {catBudget === 0 && catSpent > 0 && (
                  <div style={{ fontSize: '0.75rem', color: '#94a3b8', marginTop: '4px' }}>Set a limit to track this category</div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
