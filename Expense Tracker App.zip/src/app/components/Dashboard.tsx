import { TrendingUp, TrendingDown, Wallet, Activity, ArrowUpRight, ArrowDownRight, Plus, Zap } from 'lucide-react';
import { getTransactions, getBudget } from '../store';
import { formatCurrency, formatDate, getCurrentMonthRange, getPreviousMonthRange, CATEGORY_ICONS, CATEGORY_COLORS } from '../types';
import type { User, Transaction, NavSection } from '../types';

interface Props {
  user: User;
  refreshKey: number;
  onNavigate: (section: NavSection) => void;
  onAddTransaction: () => void;
}

function StatCard({ label, value, sub, icon, color, trend }: {
  label: string; value: string; sub?: string; icon: React.ReactNode; color: string; trend?: number;
}) {
  return (
    <div className="rounded-xl p-5" style={{ background: 'white', border: '1px solid rgba(0,0,0,0.06)', boxShadow: '0 1px 3px rgba(0,0,0,0.04)' }}>
      <div className="flex items-start justify-between mb-3">
        <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: color + '15' }}>
          <span style={{ color }}>{icon}</span>
        </div>
        {trend !== undefined && (
          <div className="flex items-center gap-1 px-2 py-0.5 rounded-full" style={{ background: trend >= 0 ? '#f0fdf4' : '#fef2f2' }}>
            {trend >= 0 ? <TrendingUp size={11} style={{ color: '#10b981' }} /> : <TrendingDown size={11} style={{ color: '#ef4444' }} />}
            <span style={{ fontSize: '0.7rem', fontWeight: 600, color: trend >= 0 ? '#10b981' : '#ef4444' }}>
              {Math.abs(trend)}%
            </span>
          </div>
        )}
      </div>
      <div style={{ fontSize: '1.5rem', fontWeight: 700, color: '#0f172a', letterSpacing: '-0.02em' }}>{value}</div>
      <div style={{ fontSize: '0.8rem', color: '#64748b', marginTop: '2px' }}>{label}</div>
      {sub && <div style={{ fontSize: '0.75rem', color: '#94a3b8', marginTop: '2px' }}>{sub}</div>}
    </div>
  );
}

function TransactionRow({ tx }: { tx: Transaction }) {
  const icon = CATEGORY_ICONS[tx.category] || '📦';
  const color = CATEGORY_COLORS[tx.category] || '#94a3b8';
  return (
    <div className="flex items-center gap-3 py-3" style={{ borderBottom: '1px solid rgba(0,0,0,0.04)' }}>
      <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: color + '15', fontSize: '1rem' }}>
        {icon}
      </div>
      <div className="flex-1 min-w-0">
        <div style={{ fontWeight: 500, fontSize: '0.875rem', color: '#0f172a', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{tx.description}</div>
        <div style={{ fontSize: '0.75rem', color: '#94a3b8' }}>{tx.category} · {formatDate(tx.date)}</div>
      </div>
      <div className="text-right flex-shrink-0">
        <div style={{ fontWeight: 600, fontSize: '0.875rem', color: tx.type === 'income' ? '#10b981' : '#0f172a' }}>
          {tx.type === 'income' ? '+' : '-'}{formatCurrency(tx.amount)}
        </div>
        <div style={{ fontSize: '0.7rem', color: '#cbd5e1', textTransform: 'capitalize' }}>{tx.paymentMethod}</div>
      </div>
    </div>
  );
}

export function Dashboard({ user, refreshKey: _refreshKey, onNavigate, onAddTransaction }: Props) {
  const transactions = getTransactions(user.id);
  const budget = getBudget(user.id);
  const { start: mStart, end: mEnd } = getCurrentMonthRange();
  const { start: pStart, end: pEnd } = getPreviousMonthRange();

  const monthTxs = transactions.filter(t => t.date >= mStart && t.date <= mEnd);
  const prevMonthTxs = transactions.filter(t => t.date >= pStart && t.date <= pEnd);

  const totalIncome = monthTxs.filter(t => t.type === 'income').reduce((s, t) => s + t.amount, 0);
  const totalExpense = monthTxs.filter(t => t.type === 'expense').reduce((s, t) => s + t.amount, 0);
  const balance = totalIncome - totalExpense;

  const prevExpense = prevMonthTxs.filter(t => t.type === 'expense').reduce((s, t) => s + t.amount, 0);
  const expenseTrend = prevExpense > 0 ? Math.round(((totalExpense - prevExpense) / prevExpense) * 100) : 0;

  const budgetUsed = budget.monthly > 0 ? Math.round((totalExpense / budget.monthly) * 100) : 0;

  // Category breakdown
  const catSpend: Record<string, number> = {};
  monthTxs.filter(t => t.type === 'expense').forEach(t => {
    catSpend[t.category] = (catSpend[t.category] || 0) + t.amount;
  });
  const topCats = Object.entries(catSpend).sort((a, b) => b[1] - a[1]).slice(0, 3);

  // Insights
  const insights: string[] = [];
  if (topCats[0]) insights.push(`"${topCats[0][0]}" is your highest expense at ${formatCurrency(topCats[0][1])} this month.`);
  if (expenseTrend > 10) insights.push(`Spending increased by ${expenseTrend}% vs last month — worth reviewing!`);
  else if (expenseTrend < -10) insights.push(`Great job! Spending dropped by ${Math.abs(expenseTrend)}% from last month.`);
  if (budget.monthly > 0) {
    const rem = budget.monthly - totalExpense;
    if (rem > 0) insights.push(`${formatCurrency(rem)} remaining in your monthly budget.`);
    else insights.push(`You've exceeded your monthly budget by ${formatCurrency(-rem)}.`);
  }

  const recent = transactions.slice(0, 10);

  return (
    <div className="p-6 space-y-6 max-w-5xl">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-foreground" style={{ fontWeight: 700, fontSize: '1.4rem', letterSpacing: '-0.02em' }}>
            Good {new Date().getHours() < 12 ? 'morning' : new Date().getHours() < 17 ? 'afternoon' : 'evening'}, {user.name.split(' ')[0]}! 👋
          </h2>
          <p style={{ color: '#64748b', fontSize: '0.875rem', marginTop: '2px' }}>
            Here's your financial overview for {new Date().toLocaleString('en-IN', { month: 'long', year: 'numeric' })}.
          </p>
        </div>
        <button
          onClick={onAddTransaction}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl transition-all"
          style={{ background: '#4f46e5', color: 'white', fontWeight: 600, fontSize: '0.875rem', boxShadow: '0 4px 12px rgba(79,70,229,0.3)' }}
          onMouseEnter={e => (e.currentTarget.style.background = '#4338ca')}
          onMouseLeave={e => (e.currentTarget.style.background = '#4f46e5')}
        >
          <Plus size={16} />
          Add Transaction
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label="Total Income" value={formatCurrency(totalIncome)} sub="This month" icon={<ArrowUpRight size={18} />} color="#10b981" />
        <StatCard label="Total Expenses" value={formatCurrency(totalExpense)} sub="This month" icon={<ArrowDownRight size={18} />} color="#ef4444" trend={expenseTrend} />
        <StatCard label="Net Balance" value={formatCurrency(balance)} sub="Income − Expenses" icon={<Wallet size={18} />} color="#4f46e5" />
        <StatCard label="Transactions" value={String(monthTxs.length)} sub="This month" icon={<Activity size={18} />} color="#f59e0b" />
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Recent transactions */}
        <div className="lg:col-span-2 rounded-xl p-5" style={{ background: 'white', border: '1px solid rgba(0,0,0,0.06)', boxShadow: '0 1px 3px rgba(0,0,0,0.04)' }}>
          <div className="flex items-center justify-between mb-1">
            <h3 style={{ fontWeight: 700, fontSize: '0.95rem', color: '#0f172a' }}>Recent Transactions</h3>
            <button onClick={() => onNavigate('transactions')} style={{ color: '#4f46e5', fontSize: '0.8rem', fontWeight: 600 }}>View all →</button>
          </div>
          {recent.length === 0 ? (
            <div className="py-10 text-center">
              <p style={{ color: '#94a3b8', fontSize: '0.875rem' }}>No transactions yet. Add one to get started!</p>
            </div>
          ) : (
            <div>
              {recent.map(tx => <TransactionRow key={tx.id} tx={tx} />)}
            </div>
          )}
        </div>

        {/* Right column */}
        <div className="space-y-4">
          {/* Budget summary */}
          {budget.monthly > 0 && (
            <div className="rounded-xl p-5" style={{ background: 'white', border: '1px solid rgba(0,0,0,0.06)', boxShadow: '0 1px 3px rgba(0,0,0,0.04)' }}>
              <div className="flex items-center justify-between mb-3">
                <h3 style={{ fontWeight: 700, fontSize: '0.95rem', color: '#0f172a' }}>Budget</h3>
                <button onClick={() => onNavigate('budget')} style={{ color: '#4f46e5', fontSize: '0.8rem', fontWeight: 600 }}>Manage →</button>
              </div>
              <div className="mb-2">
                <div className="flex justify-between mb-1">
                  <span style={{ fontSize: '0.8rem', color: '#64748b' }}>{formatCurrency(totalExpense)} spent</span>
                  <span style={{ fontSize: '0.8rem', color: '#64748b' }}>{formatCurrency(budget.monthly)} budget</span>
                </div>
                <div className="h-2.5 rounded-full overflow-hidden" style={{ background: '#f1f5f9' }}>
                  <div
                    className="h-full rounded-full transition-all"
                    style={{
                      width: `${Math.min(budgetUsed, 100)}%`,
                      background: budgetUsed > 90 ? '#ef4444' : budgetUsed > 70 ? '#f59e0b' : '#4f46e5',
                    }}
                  />
                </div>
                <div style={{ fontSize: '0.75rem', color: budgetUsed > 100 ? '#ef4444' : '#94a3b8', marginTop: 4 }}>
                  {budgetUsed}% used {budgetUsed > 100 ? '— over budget!' : ''}
                </div>
              </div>
            </div>
          )}

          {/* Top categories */}
          {topCats.length > 0 && (
            <div className="rounded-xl p-5" style={{ background: 'white', border: '1px solid rgba(0,0,0,0.06)', boxShadow: '0 1px 3px rgba(0,0,0,0.04)' }}>
              <div className="flex items-center justify-between mb-3">
                <h3 style={{ fontWeight: 700, fontSize: '0.95rem', color: '#0f172a' }}>Top Categories</h3>
                <button onClick={() => onNavigate('analytics')} style={{ color: '#4f46e5', fontSize: '0.8rem', fontWeight: 600 }}>Charts →</button>
              </div>
              <div className="space-y-2.5">
                {topCats.map(([cat, amt]) => {
                  const pct = totalExpense > 0 ? Math.round((amt / totalExpense) * 100) : 0;
                  const color = CATEGORY_COLORS[cat] || '#94a3b8';
                  return (
                    <div key={cat}>
                      <div className="flex items-center justify-between mb-1">
                        <span style={{ fontSize: '0.8rem', color: '#0f172a', fontWeight: 500 }}>
                          {CATEGORY_ICONS[cat]} {cat}
                        </span>
                        <div className="flex items-center gap-2">
                          <span style={{ fontSize: '0.75rem', color: '#64748b' }}>{pct}%</span>
                          <span style={{ fontSize: '0.8rem', fontWeight: 600, color: '#0f172a' }}>{formatCurrency(amt)}</span>
                        </div>
                      </div>
                      <div className="h-1.5 rounded-full" style={{ background: '#f1f5f9' }}>
                        <div className="h-full rounded-full" style={{ width: `${pct}%`, background: color }} />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Insights */}
          {insights.length > 0 && (
            <div className="rounded-xl p-5" style={{ background: 'linear-gradient(135deg, #4f46e5, #7c3aed)', border: 'none' }}>
              <div className="flex items-center gap-2 mb-3">
                <Zap size={15} color="white" />
                <h3 style={{ fontWeight: 700, fontSize: '0.875rem', color: 'white' }}>Spending Insights</h3>
              </div>
              <ul className="space-y-2">
                {insights.map((ins, i) => (
                  <li key={i} style={{ fontSize: '0.8rem', color: 'rgba(255,255,255,0.85)', lineHeight: 1.5 }}>
                    · {ins}
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
