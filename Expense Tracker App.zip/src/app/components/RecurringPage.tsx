import { useState } from 'react';
import { Plus, Pencil, Trash2, X, RefreshCw, ToggleLeft, ToggleRight } from 'lucide-react';
import { getRecurringTemplates, saveRecurringTemplate, deleteRecurringTemplate, generateId } from '../store';
import { formatCurrency, formatDate, EXPENSE_CATEGORIES, INCOME_CATEGORIES, PAYMENT_METHODS, CATEGORY_ICONS, CATEGORY_COLORS } from '../types';
import type { User, RecurringTemplate, TransactionType, PaymentMethod, RecurringFrequency } from '../types';

interface Props {
  user: User;
  refreshKey: number;
  onRefresh: () => void;
}

const FREQUENCIES: { value: RecurringFrequency; label: string }[] = [
  { value: 'daily', label: 'Daily' },
  { value: 'weekly', label: 'Weekly' },
  { value: 'monthly', label: 'Monthly' },
  { value: 'yearly', label: 'Yearly' },
];

function TemplateForm({ tpl, userId, onSave, onCancel }: {
  tpl?: RecurringTemplate; userId: string; onSave: () => void; onCancel: () => void;
}) {
  const [type, setType] = useState<TransactionType>(tpl?.type ?? 'expense');
  const [amount, setAmount] = useState(tpl ? String(tpl.amount) : '');
  const [category, setCategory] = useState(tpl?.category ?? '');
  const [description, setDescription] = useState(tpl?.description ?? '');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>(tpl?.paymentMethod ?? 'UPI');
  const [frequency, setFrequency] = useState<RecurringFrequency>(tpl?.frequency ?? 'monthly');
  const [nextDueDate, setNextDueDate] = useState(tpl?.nextDueDate ?? new Date().toISOString().split('T')[0]);
  const [error, setError] = useState('');

  const categories = type === 'expense' ? EXPENSE_CATEGORIES : INCOME_CATEGORIES;

  const inputStyle: React.CSSProperties = {
    width: '100%', background: '#f8fafc', border: '1.5px solid #e2e8f0', borderRadius: '0.5rem',
    padding: '0.5rem 0.75rem', fontSize: '0.875rem', color: '#0f172a', outline: 'none',
  };

  function handleSave() {
    setError('');
    const amt = parseFloat(amount);
    if (!amt || amt <= 0) { setError('Enter a valid amount.'); return; }
    if (!category) { setError('Select a category.'); return; }
    if (!description.trim()) { setError('Enter a description.'); return; }

    saveRecurringTemplate({
      id: tpl?.id ?? generateId(),
      userId,
      type,
      amount: amt,
      category,
      description: description.trim(),
      paymentMethod,
      frequency,
      nextDueDate,
      isActive: tpl?.isActive ?? true,
    });
    onSave();
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={onCancel} />
      <div className="relative w-full max-w-md rounded-2xl p-6 z-10 max-h-[90vh] overflow-y-auto" style={{ background: 'white', boxShadow: '0 25px 60px rgba(0,0,0,0.25)' }}>
        <div className="flex items-center justify-between mb-5">
          <h3 style={{ fontWeight: 700, fontSize: '1.1rem', color: '#0f172a' }}>
            {tpl ? 'Edit Recurring' : 'New Recurring'}
          </h3>
          <button onClick={onCancel} className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: '#f1f5f9' }}>
            <X size={16} style={{ color: '#64748b' }} />
          </button>
        </div>

        <div className="space-y-4">
          {/* Type */}
          <div className="flex rounded-xl overflow-hidden" style={{ background: '#f1f5f9', padding: '3px', gap: '3px' }}>
            {(['expense', 'income'] as TransactionType[]).map(t => (
              <button key={t} type="button" onClick={() => { setType(t); setCategory(''); }}
                className="flex-1 py-2 rounded-lg transition-all"
                style={{ background: type === t ? (t === 'expense' ? '#ef4444' : '#10b981') : 'transparent', color: type === t ? 'white' : '#64748b', fontWeight: type === t ? 600 : 400, fontSize: '0.875rem' }}>
                {t === 'expense' ? '💸 Expense' : '💰 Income'}
              </button>
            ))}
          </div>

          <div>
            <label style={{ fontSize: '0.8rem', fontWeight: 600, color: '#374151' }}>Amount (₹)</label>
            <input type="number" value={amount} onChange={e => setAmount(e.target.value)} placeholder="0" style={{ ...inputStyle, marginTop: 4 }}
              onFocus={e => (e.target.style.borderColor = '#4f46e5')} onBlur={e => (e.target.style.borderColor = '#e2e8f0')} />
          </div>

          <div>
            <label style={{ fontSize: '0.8rem', fontWeight: 600, color: '#374151' }}>Category</label>
            <div className="grid grid-cols-4 gap-1.5 mt-1.5">
              {categories.map(cat => (
                <button key={cat} type="button" onClick={() => setCategory(cat)}
                  className="flex flex-col items-center py-2 rounded-xl transition-all"
                  style={{ background: category === cat ? '#eef2ff' : '#f8fafc', border: `1.5px solid ${category === cat ? '#4f46e5' : '#e2e8f0'}`, fontSize: '0.65rem', color: category === cat ? '#4f46e5' : '#64748b', fontWeight: category === cat ? 600 : 400 }}>
                  <span style={{ fontSize: '1rem', marginBottom: 2 }}>{CATEGORY_ICONS[cat] || '📦'}</span>
                  {cat}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label style={{ fontSize: '0.8rem', fontWeight: 600, color: '#374151' }}>Description</label>
            <input value={description} onChange={e => setDescription(e.target.value)} placeholder="e.g. Monthly rent" style={{ ...inputStyle, marginTop: 4 }}
              onFocus={e => (e.target.style.borderColor = '#4f46e5')} onBlur={e => (e.target.style.borderColor = '#e2e8f0')} />
          </div>

          <div>
            <label style={{ fontSize: '0.8rem', fontWeight: 600, color: '#374151' }}>Frequency</label>
            <div className="flex gap-2 mt-1.5 flex-wrap">
              {FREQUENCIES.map(f => (
                <button key={f.value} type="button" onClick={() => setFrequency(f.value)}
                  className="px-3 py-1.5 rounded-lg text-sm"
                  style={{ background: frequency === f.value ? '#eef2ff' : '#f8fafc', border: `1.5px solid ${frequency === f.value ? '#4f46e5' : '#e2e8f0'}`, color: frequency === f.value ? '#4f46e5' : '#64748b', fontWeight: frequency === f.value ? 600 : 400, fontSize: '0.8rem' }}>
                  {f.label}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label style={{ fontSize: '0.8rem', fontWeight: 600, color: '#374151' }}>Next Due Date</label>
            <input type="date" value={nextDueDate} onChange={e => setNextDueDate(e.target.value)} style={{ ...inputStyle, marginTop: 4 }}
              onFocus={e => (e.target.style.borderColor = '#4f46e5')} onBlur={e => (e.target.style.borderColor = '#e2e8f0')} />
          </div>

          <div>
            <label style={{ fontSize: '0.8rem', fontWeight: 600, color: '#374151' }}>Payment Method</label>
            <div className="flex flex-wrap gap-1.5 mt-1.5">
              {PAYMENT_METHODS.map(pm => (
                <button key={pm} type="button" onClick={() => setPaymentMethod(pm)}
                  className="px-3 py-1.5 rounded-lg"
                  style={{ background: paymentMethod === pm ? '#eef2ff' : '#f8fafc', border: `1.5px solid ${paymentMethod === pm ? '#4f46e5' : '#e2e8f0'}`, color: paymentMethod === pm ? '#4f46e5' : '#64748b', fontWeight: paymentMethod === pm ? 600 : 400, fontSize: '0.8rem' }}>
                  {pm}
                </button>
              ))}
            </div>
          </div>

          {error && <div className="px-3 py-2 rounded-lg" style={{ background: '#fef2f2', border: '1px solid #fecaca' }}><p style={{ color: '#ef4444', fontSize: '0.8rem' }}>{error}</p></div>}

          <div className="flex gap-3 pt-1">
            <button onClick={onCancel} className="flex-1 py-2.5 rounded-xl" style={{ background: '#f1f5f9', color: '#64748b', fontWeight: 600, fontSize: '0.875rem' }}>Cancel</button>
            <button onClick={handleSave} className="flex-1 py-2.5 rounded-xl" style={{ background: '#4f46e5', color: 'white', fontWeight: 600, fontSize: '0.875rem' }}>Save</button>
          </div>
        </div>
      </div>
    </div>
  );
}

export function RecurringPage({ user, refreshKey: _rk, onRefresh }: Props) {
  const templates = getRecurringTemplates(user.id);
  const [showForm, setShowForm] = useState(false);
  const [editTpl, setEditTpl] = useState<RecurringTemplate | undefined>();
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null);

  const active = templates.filter(t => t.isActive);
  const inactive = templates.filter(t => !t.isActive);
  const monthlyTotal = active
    .filter(t => t.frequency === 'monthly')
    .reduce((s, t) => s + (t.type === 'expense' ? -t.amount : t.amount), 0);

  function toggleActive(tpl: RecurringTemplate) {
    saveRecurringTemplate({ ...tpl, isActive: !tpl.isActive });
    onRefresh();
  }

  function handleDelete(id: string) {
    deleteRecurringTemplate(id);
    setConfirmDelete(null);
    onRefresh();
  }

  const TplCard = ({ tpl }: { tpl: RecurringTemplate }) => {
    const color = CATEGORY_COLORS[tpl.category] || '#94a3b8';
    const dueDateObj = new Date(tpl.nextDueDate + 'T00:00:00');
    const daysUntil = Math.ceil((dueDateObj.getTime() - Date.now()) / 86400000);
    const dueSoon = daysUntil <= 7 && daysUntil >= 0;
    const overdue = daysUntil < 0;

    return (
      <div className="flex items-center gap-3 px-4 py-3.5 transition-colors" style={{ borderBottom: '1px solid rgba(0,0,0,0.04)' }}
        onMouseEnter={e => (e.currentTarget.style.background = '#fafafa')}
        onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}>
        <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: color + '15', fontSize: '1rem' }}>
          {CATEGORY_ICONS[tpl.category] || '📦'}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <span style={{ fontWeight: 600, fontSize: '0.875rem', color: '#0f172a' }}>{tpl.description}</span>
            <span className="px-2 py-0.5 rounded-full capitalize" style={{ background: color + '15', color, fontSize: '0.7rem', fontWeight: 600 }}>
              {tpl.frequency}
            </span>
            {!tpl.isActive && <span className="px-2 py-0.5 rounded-full" style={{ background: '#f1f5f9', color: '#94a3b8', fontSize: '0.7rem' }}>Paused</span>}
          </div>
          <div className="flex items-center gap-2 mt-0.5 flex-wrap">
            <span style={{ fontSize: '0.75rem', color: '#94a3b8' }}>{tpl.category} · {tpl.paymentMethod}</span>
            <span style={{ fontSize: '0.7rem', color: '#cbd5e1' }}>·</span>
            <span style={{ fontSize: '0.75rem', fontWeight: 500, color: overdue ? '#ef4444' : dueSoon ? '#f59e0b' : '#94a3b8' }}>
              {overdue ? `Overdue by ${Math.abs(daysUntil)}d` : dueSoon ? `Due in ${daysUntil}d` : `Due ${formatDate(tpl.nextDueDate)}`}
            </span>
          </div>
        </div>
        <div className="flex items-center gap-3 flex-shrink-0">
          <div className="text-right">
            <div style={{ fontWeight: 700, fontSize: '0.9rem', color: tpl.type === 'income' ? '#10b981' : '#0f172a' }}>
              {tpl.type === 'income' ? '+' : '−'}{formatCurrency(tpl.amount)}
            </div>
          </div>
          <div className="flex gap-1">
            <button onClick={() => toggleActive(tpl)} title={tpl.isActive ? 'Pause' : 'Activate'}
              className="w-7 h-7 rounded-lg flex items-center justify-center transition-colors"
              style={{ color: tpl.isActive ? '#10b981' : '#94a3b8' }}>
              {tpl.isActive ? <ToggleRight size={18} /> : <ToggleLeft size={18} />}
            </button>
            <button onClick={() => { setEditTpl(tpl); setShowForm(true); }}
              className="w-7 h-7 rounded-lg flex items-center justify-center" style={{ color: '#94a3b8' }}
              onMouseEnter={e => { e.currentTarget.style.background = '#eef2ff'; e.currentTarget.style.color = '#4f46e5'; }}
              onMouseLeave={e => { e.currentTarget.style.background = 'transparent'; e.currentTarget.style.color = '#94a3b8'; }}>
              <Pencil size={13} />
            </button>
            <button onClick={() => setConfirmDelete(tpl.id)}
              className="w-7 h-7 rounded-lg flex items-center justify-center" style={{ color: '#94a3b8' }}
              onMouseEnter={e => { e.currentTarget.style.background = '#fef2f2'; e.currentTarget.style.color = '#ef4444'; }}
              onMouseLeave={e => { e.currentTarget.style.background = 'transparent'; e.currentTarget.style.color = '#94a3b8'; }}>
              <Trash2 size={13} />
            </button>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="p-6 space-y-6 max-w-3xl">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 style={{ fontWeight: 700, fontSize: '1.4rem', color: '#0f172a', letterSpacing: '-0.02em' }}>Recurring Transactions</h2>
          <p style={{ color: '#64748b', fontSize: '0.875rem', marginTop: '2px' }}>{active.length} active, {inactive.length} paused</p>
        </div>
        <button onClick={() => { setEditTpl(undefined); setShowForm(true); }}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl"
          style={{ background: '#4f46e5', color: 'white', fontWeight: 600, fontSize: '0.875rem', boxShadow: '0 4px 12px rgba(79,70,229,0.3)' }}>
          <Plus size={16} /> Add Recurring
        </button>
      </div>

      {/* Monthly net impact */}
      {active.length > 0 && (
        <div className="rounded-xl p-4 flex items-center gap-3" style={{ background: 'linear-gradient(135deg, #4f46e5, #7c3aed)' }}>
          <RefreshCw size={20} color="white" />
          <div>
            <div style={{ color: 'rgba(255,255,255,0.7)', fontSize: '0.75rem', fontWeight: 600 }}>MONTHLY NET IMPACT FROM RECURRING</div>
            <div style={{ color: 'white', fontWeight: 700, fontSize: '1.25rem', letterSpacing: '-0.02em' }}>
              {monthlyTotal >= 0 ? '+' : ''}{formatCurrency(monthlyTotal)}
            </div>
          </div>
        </div>
      )}

      {templates.length === 0 ? (
        <div className="rounded-2xl py-20 text-center" style={{ background: 'white', border: '2px dashed #e2e8f0' }}>
          <RefreshCw size={40} style={{ color: '#e2e8f0', margin: '0 auto 12px' }} />
          <p style={{ fontWeight: 600, color: '#94a3b8' }}>No recurring transactions</p>
          <p style={{ fontSize: '0.875rem', color: '#cbd5e1', marginTop: 4 }}>Add recurring bills, subscriptions, or income</p>
          <button onClick={() => setShowForm(true)} className="mt-5 px-5 py-2.5 rounded-xl" style={{ background: '#4f46e5', color: 'white', fontWeight: 600, fontSize: '0.875rem' }}>
            + Add Recurring
          </button>
        </div>
      ) : (
        <>
          {active.length > 0 && (
            <div className="rounded-xl overflow-hidden" style={{ background: 'white', border: '1px solid rgba(0,0,0,0.06)', boxShadow: '0 1px 3px rgba(0,0,0,0.04)' }}>
              <div className="px-4 py-3" style={{ borderBottom: '1px solid rgba(0,0,0,0.04)' }}>
                <span style={{ fontSize: '0.8rem', fontWeight: 700, color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Active</span>
              </div>
              {active.map(tpl => <TplCard key={tpl.id} tpl={tpl} />)}
            </div>
          )}
          {inactive.length > 0 && (
            <div className="rounded-xl overflow-hidden" style={{ background: 'white', border: '1px solid rgba(0,0,0,0.06)', boxShadow: '0 1px 3px rgba(0,0,0,0.04)' }}>
              <div className="px-4 py-3" style={{ borderBottom: '1px solid rgba(0,0,0,0.04)' }}>
                <span style={{ fontSize: '0.8rem', fontWeight: 700, color: '#94a3b8', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Paused</span>
              </div>
              {inactive.map(tpl => <TplCard key={tpl.id} tpl={tpl} />)}
            </div>
          )}
        </>
      )}

      {showForm && (
        <TemplateForm
          tpl={editTpl}
          userId={user.id}
          onSave={() => { setShowForm(false); setEditTpl(undefined); onRefresh(); }}
          onCancel={() => { setShowForm(false); setEditTpl(undefined); }}
        />
      )}

      {confirmDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/50" onClick={() => setConfirmDelete(null)} />
          <div className="relative rounded-2xl p-6 z-10 w-full max-w-sm text-center" style={{ background: 'white', boxShadow: '0 25px 60px rgba(0,0,0,0.25)' }}>
            <div style={{ fontSize: '2rem', marginBottom: 8 }}>🗑️</div>
            <h3 style={{ fontWeight: 700, color: '#0f172a' }}>Delete this recurring?</h3>
            <p style={{ color: '#64748b', fontSize: '0.875rem', marginTop: 6 }}>This cannot be undone.</p>
            <div className="flex gap-3 mt-5">
              <button onClick={() => setConfirmDelete(null)} className="flex-1 py-2.5 rounded-xl" style={{ background: '#f1f5f9', color: '#64748b', fontWeight: 600, fontSize: '0.875rem' }}>Cancel</button>
              <button onClick={() => handleDelete(confirmDelete)} className="flex-1 py-2.5 rounded-xl" style={{ background: '#ef4444', color: 'white', fontWeight: 600, fontSize: '0.875rem' }}>Delete</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
