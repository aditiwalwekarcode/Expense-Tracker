import { useState } from 'react';
import { Plus, Pencil, Trash2, X, Target, Calendar } from 'lucide-react';
import { getSavingsGoals, saveSavingsGoal, deleteSavingsGoal, generateId } from '../store';
import { formatCurrency } from '../types';
import type { User, SavingsGoal } from '../types';

interface Props {
  user: User;
  refreshKey: number;
  onRefresh: () => void;
}

const GOAL_COLORS = ['#4f46e5', '#10b981', '#f59e0b', '#ec4899', '#8b5cf6', '#06b6d4', '#ef4444', '#84cc16'];

function expectedCompletion(goal: SavingsGoal): string {
  if (goal.currentAmount >= goal.targetAmount) return 'Completed! 🎉';
  const remaining = goal.targetAmount - goal.currentAmount;
  const target = new Date(goal.targetDate + 'T00:00:00');
  const now = new Date();
  const months = (target.getFullYear() - now.getFullYear()) * 12 + (target.getMonth() - now.getMonth());
  if (months <= 0) return 'Past target date';
  const needed = Math.ceil(remaining / months);
  return `Save ${formatCurrency(needed)}/mo to reach goal`;
}

function GoalForm({ goal, userId, onSave, onCancel }: {
  goal?: SavingsGoal; userId: string; onSave: () => void; onCancel: () => void;
}) {
  const [name, setName] = useState(goal?.name ?? '');
  const [target, setTarget] = useState(goal ? String(goal.targetAmount) : '');
  const [current, setCurrent] = useState(goal ? String(goal.currentAmount) : '');
  const [date, setDate] = useState(goal?.targetDate ?? '');
  const [desc, setDesc] = useState(goal?.description ?? '');
  const [error, setError] = useState('');

  const inputStyle: React.CSSProperties = {
    width: '100%', background: '#f8fafc', border: '1.5px solid #e2e8f0', borderRadius: '0.5rem',
    padding: '0.5rem 0.75rem', fontSize: '0.875rem', color: '#0f172a', outline: 'none',
  };

  function handleSave() {
    setError('');
    if (!name.trim()) { setError('Enter a goal name.'); return; }
    const t = parseFloat(target);
    const c = parseFloat(current) || 0;
    if (!t || t <= 0) { setError('Enter a valid target amount.'); return; }
    if (!date) { setError('Select a target date.'); return; }
    if (c < 0) { setError('Current amount cannot be negative.'); return; }

    saveSavingsGoal({
      id: goal?.id ?? generateId(),
      userId,
      name: name.trim(),
      targetAmount: t,
      currentAmount: c,
      targetDate: date,
      description: desc.trim(),
    });
    onSave();
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={onCancel} />
      <div className="relative w-full max-w-md rounded-2xl p-6 z-10" style={{ background: 'white', boxShadow: '0 25px 60px rgba(0,0,0,0.25)' }}>
        <div className="flex items-center justify-between mb-5">
          <h3 style={{ fontWeight: 700, fontSize: '1.1rem', color: '#0f172a' }}>
            {goal ? 'Edit Savings Goal' : 'New Savings Goal'}
          </h3>
          <button onClick={onCancel} className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: '#f1f5f9' }}>
            <X size={16} style={{ color: '#64748b' }} />
          </button>
        </div>
        <div className="space-y-3">
          <div>
            <label style={{ fontSize: '0.8rem', fontWeight: 600, color: '#374151' }}>Goal Name</label>
            <input value={name} onChange={e => setName(e.target.value)} placeholder="e.g. Emergency Fund" style={{ ...inputStyle, marginTop: 4 }}
              onFocus={e => (e.target.style.borderColor = '#4f46e5')} onBlur={e => (e.target.style.borderColor = '#e2e8f0')} />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label style={{ fontSize: '0.8rem', fontWeight: 600, color: '#374151' }}>Target Amount (₹)</label>
              <input type="number" value={target} onChange={e => setTarget(e.target.value)} placeholder="100000" style={{ ...inputStyle, marginTop: 4 }}
                onFocus={e => (e.target.style.borderColor = '#4f46e5')} onBlur={e => (e.target.style.borderColor = '#e2e8f0')} />
            </div>
            <div>
              <label style={{ fontSize: '0.8rem', fontWeight: 600, color: '#374151' }}>Saved So Far (₹)</label>
              <input type="number" value={current} onChange={e => setCurrent(e.target.value)} placeholder="0" style={{ ...inputStyle, marginTop: 4 }}
                onFocus={e => (e.target.style.borderColor = '#4f46e5')} onBlur={e => (e.target.style.borderColor = '#e2e8f0')} />
            </div>
          </div>
          <div>
            <label style={{ fontSize: '0.8rem', fontWeight: 600, color: '#374151' }}>Target Date</label>
            <input type="date" value={date} onChange={e => setDate(e.target.value)} style={{ ...inputStyle, marginTop: 4 }}
              onFocus={e => (e.target.style.borderColor = '#4f46e5')} onBlur={e => (e.target.style.borderColor = '#e2e8f0')} />
          </div>
          <div>
            <label style={{ fontSize: '0.8rem', fontWeight: 600, color: '#374151' }}>Description (optional)</label>
            <input value={desc} onChange={e => setDesc(e.target.value)} placeholder="What's this goal for?" style={{ ...inputStyle, marginTop: 4 }}
              onFocus={e => (e.target.style.borderColor = '#4f46e5')} onBlur={e => (e.target.style.borderColor = '#e2e8f0')} />
          </div>
          {error && <div className="px-3 py-2 rounded-lg" style={{ background: '#fef2f2', border: '1px solid #fecaca' }}><p style={{ color: '#ef4444', fontSize: '0.8rem' }}>{error}</p></div>}
          <div className="flex gap-3 pt-1">
            <button onClick={onCancel} className="flex-1 py-2.5 rounded-xl" style={{ background: '#f1f5f9', color: '#64748b', fontWeight: 600, fontSize: '0.875rem' }}>Cancel</button>
            <button onClick={handleSave} className="flex-1 py-2.5 rounded-xl" style={{ background: '#4f46e5', color: 'white', fontWeight: 600, fontSize: '0.875rem' }}>Save Goal</button>
          </div>
        </div>
      </div>
    </div>
  );
}

export function SavingsPage({ user, refreshKey: _rk, onRefresh }: Props) {
  const goals = getSavingsGoals(user.id);
  const [showForm, setShowForm] = useState(false);
  const [editGoal, setEditGoal] = useState<SavingsGoal | undefined>();
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null);
  const [depositGoalId, setDepositGoalId] = useState<string | null>(null);
  const [depositAmount, setDepositAmount] = useState('');

  function handleDelete(id: string) {
    deleteSavingsGoal(id);
    setConfirmDelete(null);
    onRefresh();
  }

  function handleDeposit(goal: SavingsGoal) {
    const amt = parseFloat(depositAmount);
    if (!amt || amt <= 0) return;
    saveSavingsGoal({ ...goal, currentAmount: Math.min(goal.currentAmount + amt, goal.targetAmount) });
    setDepositGoalId(null);
    setDepositAmount('');
    onRefresh();
  }

  const totalTarget = goals.reduce((s, g) => s + g.targetAmount, 0);
  const totalSaved = goals.reduce((s, g) => s + g.currentAmount, 0);

  return (
    <div className="p-6 space-y-6 max-w-4xl">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 style={{ fontWeight: 700, fontSize: '1.4rem', color: '#0f172a', letterSpacing: '-0.02em' }}>Savings Goals</h2>
          <p style={{ color: '#64748b', fontSize: '0.875rem', marginTop: '2px' }}>{goals.length} active {goals.length === 1 ? 'goal' : 'goals'}</p>
        </div>
        <button
          onClick={() => { setEditGoal(undefined); setShowForm(true); }}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl"
          style={{ background: '#4f46e5', color: 'white', fontWeight: 600, fontSize: '0.875rem', boxShadow: '0 4px 12px rgba(79,70,229,0.3)' }}
        >
          <Plus size={16} /> New Goal
        </button>
      </div>

      {/* Summary */}
      {goals.length > 0 && (
        <div className="grid grid-cols-3 gap-3">
          {[
            { label: 'Total Target', value: formatCurrency(totalTarget), color: '#0f172a', bg: 'white' },
            { label: 'Total Saved', value: formatCurrency(totalSaved), color: '#10b981', bg: '#f0fdf4' },
            { label: 'Remaining', value: formatCurrency(totalTarget - totalSaved), color: '#4f46e5', bg: '#eef2ff' },
          ].map(s => (
            <div key={s.label} className="rounded-xl p-4 text-center" style={{ background: s.bg, border: '1px solid rgba(0,0,0,0.06)', boxShadow: '0 1px 3px rgba(0,0,0,0.04)' }}>
              <div style={{ fontSize: '1.25rem', fontWeight: 700, color: s.color, letterSpacing: '-0.02em' }}>{s.value}</div>
              <div style={{ fontSize: '0.75rem', color: '#64748b', marginTop: 2 }}>{s.label}</div>
            </div>
          ))}
        </div>
      )}

      {/* Goals grid */}
      {goals.length === 0 ? (
        <div className="rounded-2xl py-20 text-center" style={{ background: 'white', border: '2px dashed #e2e8f0' }}>
          <Target size={40} style={{ color: '#e2e8f0', margin: '0 auto 12px' }} />
          <p style={{ fontWeight: 600, color: '#94a3b8' }}>No savings goals yet</p>
          <p style={{ fontSize: '0.875rem', color: '#cbd5e1', marginTop: 4 }}>Create your first goal to start saving</p>
          <button onClick={() => setShowForm(true)} className="mt-5 px-5 py-2.5 rounded-xl" style={{ background: '#4f46e5', color: 'white', fontWeight: 600, fontSize: '0.875rem' }}>
            + Add Goal
          </button>
        </div>
      ) : (
        <div className="grid md:grid-cols-2 gap-4">
          {goals.map((goal, idx) => {
            const pct = Math.min((goal.currentAmount / goal.targetAmount) * 100, 100);
            const color = GOAL_COLORS[idx % GOAL_COLORS.length];
            const completed = goal.currentAmount >= goal.targetAmount;
            const target = new Date(goal.targetDate + 'T00:00:00');
            const daysLeft = Math.ceil((target.getTime() - Date.now()) / 86400000);

            return (
              <div key={goal.id} className="rounded-xl p-5" style={{ background: 'white', border: '1px solid rgba(0,0,0,0.06)', boxShadow: '0 1px 3px rgba(0,0,0,0.04)' }}>
                {/* Header */}
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-2.5">
                    <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: color + '15' }}>
                      <Target size={18} style={{ color }} />
                    </div>
                    <div>
                      <div style={{ fontWeight: 700, fontSize: '0.95rem', color: '#0f172a' }}>{goal.name}</div>
                      {goal.description && <div style={{ fontSize: '0.75rem', color: '#94a3b8', marginTop: 1 }}>{goal.description}</div>}
                    </div>
                  </div>
                  <div className="flex gap-1">
                    <button onClick={() => { setEditGoal(goal); setShowForm(true); }} className="w-7 h-7 rounded-lg flex items-center justify-center" style={{ color: '#94a3b8' }}
                      onMouseEnter={e => { e.currentTarget.style.background = '#eef2ff'; e.currentTarget.style.color = '#4f46e5'; }}
                      onMouseLeave={e => { e.currentTarget.style.background = 'transparent'; e.currentTarget.style.color = '#94a3b8'; }}>
                      <Pencil size={13} />
                    </button>
                    <button onClick={() => setConfirmDelete(goal.id)} className="w-7 h-7 rounded-lg flex items-center justify-center" style={{ color: '#94a3b8' }}
                      onMouseEnter={e => { e.currentTarget.style.background = '#fef2f2'; e.currentTarget.style.color = '#ef4444'; }}
                      onMouseLeave={e => { e.currentTarget.style.background = 'transparent'; e.currentTarget.style.color = '#94a3b8'; }}>
                      <Trash2 size={13} />
                    </button>
                  </div>
                </div>

                {/* Amounts */}
                <div className="flex items-end justify-between mb-2">
                  <div>
                    <span style={{ fontSize: '1.35rem', fontWeight: 700, color, letterSpacing: '-0.02em' }}>{formatCurrency(goal.currentAmount)}</span>
                    <span style={{ fontSize: '0.8rem', color: '#94a3b8' }}> / {formatCurrency(goal.targetAmount)}</span>
                  </div>
                  <span style={{ fontSize: '0.8rem', fontWeight: 700, color: completed ? '#10b981' : color }}>{pct.toFixed(0)}%</span>
                </div>

                {/* Progress bar */}
                <div className="h-2.5 rounded-full overflow-hidden mb-3" style={{ background: '#f1f5f9' }}>
                  <div className="h-full rounded-full transition-all" style={{ width: `${pct}%`, background: completed ? '#10b981' : color }} />
                </div>

                {/* Meta */}
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-1.5">
                    <Calendar size={13} style={{ color: '#94a3b8' }} />
                    <span style={{ fontSize: '0.75rem', color: '#64748b' }}>
                      {target.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}
                    </span>
                  </div>
                  <span style={{ fontSize: '0.75rem', color: daysLeft < 0 ? '#ef4444' : daysLeft < 30 ? '#f59e0b' : '#10b981', fontWeight: 500 }}>
                    {daysLeft < 0 ? `${Math.abs(daysLeft)}d overdue` : `${daysLeft}d left`}
                  </span>
                </div>

                <div className="rounded-lg px-3 py-2 mb-3" style={{ background: '#f8fafc' }}>
                  <p style={{ fontSize: '0.75rem', color: '#64748b' }}>{expectedCompletion(goal)}</p>
                </div>

                {/* Deposit */}
                {!completed && (
                  depositGoalId === goal.id ? (
                    <div className="flex gap-2">
                      <input
                        type="number"
                        value={depositAmount}
                        onChange={e => setDepositAmount(e.target.value)}
                        placeholder="Amount to add"
                        className="flex-1 rounded-lg px-3 py-1.5"
                        style={{ background: '#f8fafc', border: '1.5px solid #e2e8f0', fontSize: '0.8rem', outline: 'none' }}
                        onFocus={e => (e.target.style.borderColor = color)}
                        onBlur={e => (e.target.style.borderColor = '#e2e8f0')}
                      />
                      <button onClick={() => handleDeposit(goal)} className="px-3 py-1.5 rounded-lg" style={{ background: color, color: 'white', fontWeight: 600, fontSize: '0.8rem' }}>Add</button>
                      <button onClick={() => { setDepositGoalId(null); setDepositAmount(''); }} className="px-2 py-1.5 rounded-lg" style={{ background: '#f1f5f9', color: '#64748b', fontSize: '0.8rem' }}>✕</button>
                    </div>
                  ) : (
                    <button
                      onClick={() => setDepositGoalId(goal.id)}
                      className="w-full py-2 rounded-lg transition-all"
                      style={{ background: color + '10', color, fontWeight: 600, fontSize: '0.8rem', border: `1.5px solid ${color}30` }}
                      onMouseEnter={e => { e.currentTarget.style.background = color + '20'; }}
                      onMouseLeave={e => { e.currentTarget.style.background = color + '10'; }}
                    >
                      + Add Savings
                    </button>
                  )
                )}
                {completed && (
                  <div className="py-2 rounded-lg text-center" style={{ background: '#f0fdf4', border: '1px solid #bbf7d0' }}>
                    <span style={{ fontSize: '0.85rem', color: '#16a34a', fontWeight: 600 }}>🎉 Goal Achieved!</span>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {showForm && (
        <GoalForm
          goal={editGoal}
          userId={user.id}
          onSave={() => { setShowForm(false); setEditGoal(undefined); onRefresh(); }}
          onCancel={() => { setShowForm(false); setEditGoal(undefined); }}
        />
      )}

      {confirmDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/50" onClick={() => setConfirmDelete(null)} />
          <div className="relative rounded-2xl p-6 z-10 w-full max-w-sm text-center" style={{ background: 'white', boxShadow: '0 25px 60px rgba(0,0,0,0.25)' }}>
            <div style={{ fontSize: '2rem', marginBottom: 8 }}>🗑️</div>
            <h3 style={{ fontWeight: 700, color: '#0f172a' }}>Delete this goal?</h3>
            <p style={{ color: '#64748b', fontSize: '0.875rem', marginTop: 6 }}>This cannot be undone.</p>
            <div className="flex gap-3 mt-5">
              <button onClick={() => setConfirmDelete(null)} className="flex-1 py-2.5 rounded-xl" style={{ background: '#f1f5f9', color: '#64748b', fontWeight: 600, fontSize: '0.875rem' }}>Cancel</button>
              <button onClick={() => handleDelete(confirmDelete)} className="flex-1 py-2.5 rounded-xl" style={{ background: '#ef4444', color: 'white', fontWeight: 600, fontSize: '0.875rem' }}>Delete</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
