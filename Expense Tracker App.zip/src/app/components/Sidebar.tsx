import { TrendingUp, LayoutDashboard, ArrowLeftRight, PieChart, Target, RefreshCw, Wallet, LogOut, Menu, X } from 'lucide-react';
import { useState } from 'react';
import type { NavSection, User } from '../types';

interface NavItem {
  id: NavSection;
  label: string;
  icon: React.ReactNode;
}

const NAV_ITEMS: NavItem[] = [
  { id: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard size={18} /> },
  { id: 'transactions', label: 'Transactions', icon: <ArrowLeftRight size={18} /> },
  { id: 'budget', label: 'Budget', icon: <Wallet size={18} /> },
  { id: 'analytics', label: 'Analytics', icon: <PieChart size={18} /> },
  { id: 'savings', label: 'Savings Goals', icon: <Target size={18} /> },
  { id: 'recurring', label: 'Recurring', icon: <RefreshCw size={18} /> },
];

interface Props {
  user: User;
  current: NavSection;
  onChange: (section: NavSection) => void;
  onLogout: () => void;
}

export function Sidebar({ user, current, onChange, onLogout }: Props) {
  const [mobileOpen, setMobileOpen] = useState(false);

  const navContent = (
    <div className="flex flex-col h-full">
      {/* Logo */}
      <div className="px-5 py-5 flex items-center gap-3" style={{ borderBottom: '1px solid rgba(255,255,255,0.08)' }}>
        <div className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0" style={{ background: '#4f46e5' }}>
          <TrendingUp size={16} color="white" />
        </div>
        <span style={{ color: '#f1f5f9', fontWeight: 700, fontSize: '1.05rem', letterSpacing: '-0.01em' }}>FinTrack</span>
      </div>

      {/* Nav */}
      <nav className="flex-1 px-3 py-4 space-y-0.5 overflow-y-auto">
        {NAV_ITEMS.map(item => {
          const active = current === item.id;
          return (
            <button
              key={item.id}
              onClick={() => { onChange(item.id); setMobileOpen(false); }}
              className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all text-left"
              style={{
                background: active ? 'rgba(79,70,229,0.2)' : 'transparent',
                color: active ? '#818cf8' : '#94a3b8',
                fontWeight: active ? 600 : 400,
                fontSize: '0.875rem',
              }}
              onMouseEnter={e => { if (!active) (e.currentTarget as HTMLButtonElement).style.background = 'rgba(255,255,255,0.05)'; }}
              onMouseLeave={e => { if (!active) (e.currentTarget as HTMLButtonElement).style.background = 'transparent'; }}
            >
              <span style={{ color: active ? '#818cf8' : '#64748b' }}>{item.icon}</span>
              {item.label}
              {active && <span className="ml-auto w-1.5 h-1.5 rounded-full" style={{ background: '#818cf8' }} />}
            </button>
          );
        })}
      </nav>

      {/* User info + logout */}
      <div className="px-3 py-4" style={{ borderTop: '1px solid rgba(255,255,255,0.08)' }}>
        <div className="flex items-center gap-3 px-2 mb-2">
          <div className="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0" style={{ background: 'linear-gradient(135deg, #4f46e5, #818cf8)' }}>
            <span style={{ color: 'white', fontWeight: 700, fontSize: '0.75rem' }}>
              {user.name.charAt(0).toUpperCase()}
            </span>
          </div>
          <div className="min-w-0">
            <div style={{ color: '#f1f5f9', fontWeight: 600, fontSize: '0.8rem', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{user.name}</div>
            <div style={{ color: '#475569', fontSize: '0.7rem', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{user.email}</div>
          </div>
        </div>
        <button
          onClick={onLogout}
          className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg transition-all"
          style={{ color: '#64748b', fontSize: '0.875rem' }}
          onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.color = '#ef4444'; (e.currentTarget as HTMLButtonElement).style.background = 'rgba(239,68,68,0.08)'; }}
          onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.color = '#64748b'; (e.currentTarget as HTMLButtonElement).style.background = 'transparent'; }}
        >
          <LogOut size={15} />
          Sign out
        </button>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop sidebar */}
      <aside className="hidden lg:flex flex-col w-60 flex-shrink-0 h-screen sticky top-0" style={{ background: '#0f172a' }}>
        {navContent}
      </aside>

      {/* Mobile top bar */}
      <div className="lg:hidden fixed top-0 left-0 right-0 z-40 flex items-center justify-between px-4 py-3" style={{ background: '#0f172a', borderBottom: '1px solid rgba(255,255,255,0.08)' }}>
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg flex items-center justify-center" style={{ background: '#4f46e5' }}>
            <TrendingUp size={14} color="white" />
          </div>
          <span style={{ color: '#f1f5f9', fontWeight: 700, fontSize: '0.95rem' }}>FinTrack</span>
        </div>
        <button onClick={() => setMobileOpen(v => !v)} style={{ color: '#94a3b8' }}>
          {mobileOpen ? <X size={22} /> : <Menu size={22} />}
        </button>
      </div>

      {/* Mobile drawer */}
      {mobileOpen && (
        <div className="lg:hidden fixed inset-0 z-50 flex">
          <div className="absolute inset-0 bg-black/60" onClick={() => setMobileOpen(false)} />
          <div className="relative w-64 h-full" style={{ background: '#0f172a' }}>
            {navContent}
          </div>
        </div>
      )}
    </>
  );
}
