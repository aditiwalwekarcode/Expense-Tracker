import { useState, useEffect } from 'react';
import { X } from 'lucide-react';
import { saveTransaction, generateId } from '../store';
import { EXPENSE_CATEGORIES, INCOME_CATEGORIES, PAYMENT_METHODS, CATEGORY_ICONS } from '../types';
import type { Transaction, TransactionType, PaymentMethod, User } from '../types';

interface Props {
  user: User;
  transaction?: Transaction;
  defaultType?: TransactionType;
  onClose: () => void;
  onSave: () => void;
}

const today = new Date().toISOString().split('T')[0];

export function TransactionModal({ user, transaction, defaultType = 'expense', onClose, onSave }: Props) {
  const [type, setType] = useState<TransactionType>(transaction?.type ?? defaultType);
  const [amount, setAmount] = useState(transaction ? String(transaction.amount) : '');
  const [category, setCategory] = useState(transaction?.category ?? '');
  const [date, setDate] = useState(transaction?.date ?? today);
  const [description, setDescription] = useState(transaction?.description ?? '');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>(transaction?.paymentMethod ?? 'UPI');
  const [isRecurring, setIsRecurring] = useState(transaction?.isRecurring ?? false);
  const [error, setError] = useState('');

  const categories = type === 'expense' ? EXPENSE_CATEGORIES : INCOME_CATEGORIES;

  useEffect(() => {
    if (!categories.includes(category)) setCategory('');
  }, [type]);

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    const amt = parseFloat(amount);
    if (!amt || amt <= 0) { setError('Enter a valid amount.'); return; }
    if (!category) { setError('Select a category.'); return; }
    if (!description.trim()) { setError('Enter a description.'); return; }

    const tx: Transaction = {
      id: transaction?.id ?? generateId(),
      userId: user.id,
      type,
      amount: amt,
      category,
      date,
      description: description.trim(),
      paymentMethod,
      isRecurring,
    };
    saveTransaction(tx);
    onSave();
  }

  const inputStyle: React.CSSProperties = {
    width: '100%',
    background: '#f8fafc',
    border: '1.5px solid #e2e8f0',
    borderRadius: '0.625rem',
    padding: '0.5rem 0.75rem',
    fontSize: '0.9rem',
    color: '#0f172a',
    outline: 'none',
    transition: 'border-color 0.15s',
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={onClose} />
      <div className="relative w-full max-w-md rounded-2xl p-6 z-10 max-h-[90vh] overflow-y-auto" style={{ background: 'white', boxShadow: '0 25px 60px rgba(0,0,0,0.25)' }}>
        {/* Header */}
        <div className="flex items-center justify-between mb-5">
          <h3 style={{ fontWeight: 700, fontSize: '1.1rem', color: '#0f172a' }}>
            {transaction ? 'Edit Transaction' : 'Add Transaction'}
          </h3>
          <button onClick={onClose} className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: '#f1f5f9' }}>
            <X size={16} style={{ color: '#64748b' }} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Type toggle */}
          <div className="flex rounded-xl overflow-hidden" style={{ background: '#f1f5f9', padding: '3px', gap: '3px' }}>
            {(['expense', 'income'] as TransactionType[]).map(t => (
              <button
                key={t}
                type="button"
                onClick={() => setType(t)}
                className="flex-1 py-2 rounded-lg transition-all capitalize"
                style={{
                  background: type === t ? (t === 'expense' ? '#ef4444' : '#10b981') : 'transparent',
                  color: type === t ? 'white' : '#64748b',
                  fontWeight: type === t ? 600 : 400,
                  fontSize: '0.875rem',
                }}
              >
                {t === 'expense' ? '💸 Expense' : '💰 Income'}
              </button>
            ))}
          </div>

          {/* Amount */}
          <div>
            <label style={{ fontSize: '0.8rem', fontWeight: 600, color: '#374151' }}>Amount (₹)</label>
            <input
              type="number"
              value={amount}
              onChange={e => setAmount(e.target.value)}
              placeholder="0"
              min="0"
              step="0.01"
              required
              style={{ ...inputStyle, marginTop: '4px' }}
              onFocus={e => (e.target.style.borderColor = '#4f46e5')}
              onBlur={e => (e.target.style.borderColor = '#e2e8f0')}
            />
          </div>

          {/* Category */}
          <div>
            <label style={{ fontSize: '0.8rem', fontWeight: 600, color: '#374151' }}>Category</label>
            <div className="grid grid-cols-4 gap-1.5 mt-1.5">
              {categories.map(cat => (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setCategory(cat)}
                  className="flex flex-col items-center justify-center py-2 rounded-xl transition-all"
                  style={{
                    background: category === cat ? '#eef2ff' : '#f8fafc',
                    border: `1.5px solid ${category === cat ? '#4f46e5' : '#e2e8f0'}`,
                    fontSize: '0.65rem',
                    color: category === cat ? '#4f46e5' : '#64748b',
                    fontWeight: category === cat ? 600 : 400,
                  }}
                >
                  <span style={{ fontSize: '1.1rem', marginBottom: '2px' }}>{CATEGORY_ICONS[cat] || '📦'}</span>
                  {cat}
                </button>
              ))}
            </div>
          </div>

          {/* Date */}
          <div>
            <label style={{ fontSize: '0.8rem', fontWeight: 600, color: '#374151' }}>Date</label>
            <input
              type="date"
              value={date}
              onChange={e => setDate(e.target.value)}
              required
              style={{ ...inputStyle, marginTop: '4px' }}
              onFocus={e => (e.target.style.borderColor = '#4f46e5')}
              onBlur={e => (e.target.style.borderColor = '#e2e8f0')}
            />
          </div>

          {/* Description */}
          <div>
            <label style={{ fontSize: '0.8rem', fontWeight: 600, color: '#374151' }}>Description</label>
            <input
              type="text"
              value={description}
              onChange={e => setDescription(e.target.value)}
              placeholder="What's this for?"
              required
              style={{ ...inputStyle, marginTop: '4px' }}
              onFocus={e => (e.target.style.borderColor = '#4f46e5')}
              onBlur={e => (e.target.style.borderColor = '#e2e8f0')}
            />
          </div>

          {/* Payment Method */}
          <div>
            <label style={{ fontSize: '0.8rem', fontWeight: 600, color: '#374151' }}>Payment Method</label>
            <div className="flex flex-wrap gap-1.5 mt-1.5">
              {PAYMENT_METHODS.map(pm => (
                <button
                  key={pm}
                  type="button"
                  onClick={() => setPaymentMethod(pm)}
                  className="px-3 py-1.5 rounded-lg text-sm transition-all"
                  style={{
                    background: paymentMethod === pm ? '#eef2ff' : '#f8fafc',
                    border: `1.5px solid ${paymentMethod === pm ? '#4f46e5' : '#e2e8f0'}`,
                    color: paymentMethod === pm ? '#4f46e5' : '#64748b',
                    fontWeight: paymentMethod === pm ? 600 : 400,
                    fontSize: '0.8rem',
                  }}
                >
                  {pm}
                </button>
              ))}
            </div>
          </div>

          {/* Recurring toggle */}
          <div className="flex items-center justify-between py-2.5 px-3 rounded-xl" style={{ background: '#f8fafc', border: '1.5px solid #e2e8f0' }}>
            <div>
              <div style={{ fontWeight: 500, fontSize: '0.875rem', color: '#0f172a' }}>Recurring Transaction</div>
              <div style={{ fontSize: '0.75rem', color: '#94a3b8' }}>Mark if this repeats regularly</div>
            </div>
            <button
              type="button"
              onClick={() => setIsRecurring(v => !v)}
              className="w-11 h-6 rounded-full transition-all flex-shrink-0"
              style={{ background: isRecurring ? '#4f46e5' : '#e2e8f0', position: 'relative' }}
            >
              <span
                className="absolute top-0.5 w-5 h-5 rounded-full bg-white transition-all shadow-sm"
                style={{ left: isRecurring ? 'calc(100% - 22px)' : '2px' }}
              />
            </button>
          </div>

          {error && (
            <div className="px-3 py-2 rounded-lg" style={{ background: '#fef2f2', border: '1px solid #fecaca' }}>
              <p style={{ color: '#ef4444', fontSize: '0.8rem', fontWeight: 500 }}>{error}</p>
            </div>
          )}

          <div className="flex gap-3 pt-1">
            <button type="button" onClick={onClose} className="flex-1 py-2.5 rounded-xl" style={{ background: '#f1f5f9', color: '#64748b', fontWeight: 600, fontSize: '0.875rem' }}>
              Cancel
            </button>
            <button
              type="submit"
              className="flex-1 py-2.5 rounded-xl transition-all"
              style={{ background: '#4f46e5', color: 'white', fontWeight: 600, fontSize: '0.875rem', boxShadow: '0 4px 12px rgba(79,70,229,0.3)' }}
            >
              {transaction ? 'Update' : 'Save'} Transaction
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
