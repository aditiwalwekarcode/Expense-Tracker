import { useState, useMemo } from 'react';
import { Search, Filter, Plus, Pencil, Trash2, X, ChevronDown } from 'lucide-react';
import { getTransactions, deleteTransaction } from '../store';
import { formatCurrency, formatDate, EXPENSE_CATEGORIES, INCOME_CATEGORIES, PAYMENT_METHODS, CATEGORY_ICONS, CATEGORY_COLORS } from '../types';
import type { User, Transaction, PaymentMethod } from '../types';
import { TransactionModal } from './TransactionModal';

interface Props {
  user: User;
  refreshKey: number;
  onRefresh: () => void;
}

const ALL_CATEGORIES = ['All', ...EXPENSE_CATEGORIES, ...INCOME_CATEGORIES.filter(c => !EXPENSE_CATEGORIES.includes(c))];

function Badge({ children, color }: { children: React.ReactNode; color: string }) {
  return (
    <span className="inline-flex items-center px-2 py-0.5 rounded-full" style={{ background: color + '15', color, fontSize: '0.7rem', fontWeight: 600 }}>
      {children}
    </span>
  );
}

export function TransactionsPage({ user, refreshKey: _rk, onRefresh }: Props) {
  const [search, setSearch] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'expense' | 'income'>('all');
  const [filterCategory, setFilterCategory] = useState('All');
  const [filterPayment, setFilterPayment] = useState<PaymentMethod | 'All'>('All');
  const [minAmount, setMinAmount] = useState('');
  const [maxAmount, setMaxAmount] = useState('');
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');
  const [showFilters, setShowFilters] = useState(false);
  const [editTx, setEditTx] = useState<Transaction | undefined>();
  const [showModal, setShowModal] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null);

  const transactions = getTransactions(user.id);

  const filtered = useMemo(() => {
    return transactions.filter(tx => {
      if (filterType !== 'all' && tx.type !== filterType) return false;
      if (filterCategory !== 'All' && tx.category !== filterCategory) return false;
      if (filterPayment !== 'All' && tx.paymentMethod !== filterPayment) return false;
      if (minAmount && tx.amount < parseFloat(minAmount)) return false;
      if (maxAmount && tx.amount > parseFloat(maxAmount)) return false;
      if (dateFrom && tx.date < dateFrom) return false;
      if (dateTo && tx.date > dateTo) return false;
      if (search) {
        const q = search.toLowerCase();
        if (!tx.description.toLowerCase().includes(q) && !tx.category.toLowerCase().includes(q)) return false;
      }
      return true;
    });
  }, [transactions, filterType, filterCategory, filterPayment, minAmount, maxAmount, dateFrom, dateTo, search]);

  const totalExpense = filtered.filter(t => t.type === 'expense').reduce((s, t) => s + t.amount, 0);
  const totalIncome = filtered.filter(t => t.type === 'income').reduce((s, t) => s + t.amount, 0);

  function handleDelete(id: string) {
    deleteTransaction(id);
    setConfirmDelete(null);
    onRefresh();
  }

  const inputStyle: React.CSSProperties = {
    background: '#f8fafc', border: '1.5px solid #e2e8f0', borderRadius: '0.625rem',
    padding: '0.5rem 0.75rem', fontSize: '0.8rem', color: '#0f172a', outline: 'none',
  };

  return (
    <div className="p-6 space-y-5 max-w-4xl">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 style={{ fontWeight: 700, fontSize: '1.4rem', color: '#0f172a', letterSpacing: '-0.02em' }}>Transactions</h2>
          <p style={{ color: '#64748b', fontSize: '0.875rem', marginTop: '2px' }}>{filtered.length} records</p>
        </div>
        <button
          onClick={() => { setEditTx(undefined); setShowModal(true); }}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl transition-all"
          style={{ background: '#4f46e5', color: 'white', fontWeight: 600, fontSize: '0.875rem', boxShadow: '0 4px 12px rgba(79,70,229,0.3)' }}
        >
          <Plus size={16} />
          Add
        </button>
      </div>

      {/* Search + filter bar */}
      <div className="rounded-xl p-4 space-y-3" style={{ background: 'white', border: '1px solid rgba(0,0,0,0.06)', boxShadow: '0 1px 3px rgba(0,0,0,0.04)' }}>
        <div className="flex gap-2 flex-wrap">
          <div className="flex-1 min-w-48 relative">
            <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: '#94a3b8' }} />
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search transactions…"
              style={{ ...inputStyle, paddingLeft: '2.25rem', width: '100%' }}
            />
          </div>
          {/* Type buttons */}
          <div className="flex rounded-lg overflow-hidden" style={{ border: '1.5px solid #e2e8f0' }}>
            {(['all', 'expense', 'income'] as const).map(t => (
              <button
                key={t}
                onClick={() => setFilterType(t)}
                className="px-3 py-2 transition-all capitalize"
                style={{
                  background: filterType === t ? '#4f46e5' : 'white',
                  color: filterType === t ? 'white' : '#64748b',
                  fontWeight: filterType === t ? 600 : 400,
                  fontSize: '0.8rem',
                  borderRight: t !== 'income' ? '1.5px solid #e2e8f0' : 'none',
                }}
              >
                {t}
              </button>
            ))}
          </div>
          <button
            onClick={() => setShowFilters(v => !v)}
            className="flex items-center gap-1.5 px-3 py-2 rounded-lg transition-all"
            style={{ background: showFilters ? '#eef2ff' : '#f8fafc', border: '1.5px solid', borderColor: showFilters ? '#4f46e5' : '#e2e8f0', color: showFilters ? '#4f46e5' : '#64748b', fontSize: '0.8rem', fontWeight: 500 }}
          >
            <Filter size={13} />
            Filters
            <ChevronDown size={12} style={{ transform: showFilters ? 'rotate(180deg)' : 'none', transition: 'transform 0.2s' }} />
          </button>
        </div>

        {showFilters && (
          <div className="grid grid-cols-2 md:grid-cols-3 gap-2 pt-2" style={{ borderTop: '1px solid #f1f5f9' }}>
            <div>
              <div style={{ fontSize: '0.7rem', color: '#94a3b8', fontWeight: 600, marginBottom: '4px' }}>CATEGORY</div>
              <select
                value={filterCategory}
                onChange={e => setFilterCategory(e.target.value)}
                style={{ ...inputStyle, width: '100%' }}
              >
                {ALL_CATEGORIES.map(c => <option key={c}>{c}</option>)}
              </select>
            </div>
            <div>
              <div style={{ fontSize: '0.7rem', color: '#94a3b8', fontWeight: 600, marginBottom: '4px' }}>PAYMENT</div>
              <select
                value={filterPayment}
                onChange={e => setFilterPayment(e.target.value as PaymentMethod | 'All')}
                style={{ ...inputStyle, width: '100%' }}
              >
                <option value="All">All</option>
                {PAYMENT_METHODS.map(p => <option key={p}>{p}</option>)}
              </select>
            </div>
            <div>
              <div style={{ fontSize: '0.7rem', color: '#94a3b8', fontWeight: 600, marginBottom: '4px' }}>AMOUNT RANGE</div>
              <div className="flex gap-1">
                <input type="number" value={minAmount} onChange={e => setMinAmount(e.target.value)} placeholder="Min" style={{ ...inputStyle, flex: 1, minWidth: 0 }} />
                <input type="number" value={maxAmount} onChange={e => setMaxAmount(e.target.value)} placeholder="Max" style={{ ...inputStyle, flex: 1, minWidth: 0 }} />
              </div>
            </div>
            <div>
              <div style={{ fontSize: '0.7rem', color: '#94a3b8', fontWeight: 600, marginBottom: '4px' }}>DATE FROM</div>
              <input type="date" value={dateFrom} onChange={e => setDateFrom(e.target.value)} style={{ ...inputStyle, width: '100%' }} />
            </div>
            <div>
              <div style={{ fontSize: '0.7rem', color: '#94a3b8', fontWeight: 600, marginBottom: '4px' }}>DATE TO</div>
              <input type="date" value={dateTo} onChange={e => setDateTo(e.target.value)} style={{ ...inputStyle, width: '100%' }} />
            </div>
            <div className="flex items-end">
              <button
                onClick={() => { setFilterCategory('All'); setFilterPayment('All'); setMinAmount(''); setMaxAmount(''); setDateFrom(''); setDateTo(''); setSearch(''); setFilterType('all'); }}
                className="flex items-center gap-1 px-3 py-2 rounded-lg w-full justify-center"
                style={{ background: '#fef2f2', border: '1.5px solid #fecaca', color: '#ef4444', fontSize: '0.8rem', fontWeight: 500 }}
              >
                <X size={12} /> Clear All
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Summary strip */}
      {filtered.length > 0 && (
        <div className="flex gap-3 flex-wrap">
          <div className="rounded-lg px-4 py-2.5" style={{ background: '#f0fdf4', border: '1px solid #bbf7d0' }}>
            <span style={{ fontSize: '0.75rem', color: '#16a34a', fontWeight: 600 }}>Income: {formatCurrency(totalIncome)}</span>
          </div>
          <div className="rounded-lg px-4 py-2.5" style={{ background: '#fef2f2', border: '1px solid #fecaca' }}>
            <span style={{ fontSize: '0.75rem', color: '#ef4444', fontWeight: 600 }}>Expenses: {formatCurrency(totalExpense)}</span>
          </div>
          <div className="rounded-lg px-4 py-2.5" style={{ background: '#eef2ff', border: '1px solid #c7d2fe' }}>
            <span style={{ fontSize: '0.75rem', color: '#4f46e5', fontWeight: 600 }}>Net: {formatCurrency(totalIncome - totalExpense)}</span>
          </div>
        </div>
      )}

      {/* Transactions list */}
      <div className="rounded-xl overflow-hidden" style={{ background: 'white', border: '1px solid rgba(0,0,0,0.06)', boxShadow: '0 1px 3px rgba(0,0,0,0.04)' }}>
        {filtered.length === 0 ? (
          <div className="py-16 text-center">
            <div style={{ fontSize: '2.5rem', marginBottom: '8px' }}>🔍</div>
            <p style={{ color: '#64748b', fontWeight: 500 }}>No transactions found</p>
            <p style={{ color: '#94a3b8', fontSize: '0.875rem', marginTop: '4px' }}>Try adjusting your search or filters</p>
          </div>
        ) : (
          <div>
            {filtered.map((tx, i) => {
              const color = CATEGORY_COLORS[tx.category] || '#94a3b8';
              const icon = CATEGORY_ICONS[tx.category] || '📦';
              return (
                <div
                  key={tx.id}
                  className="flex items-center gap-3 px-4 py-3.5 transition-colors"
                  style={{ borderBottom: i < filtered.length - 1 ? '1px solid rgba(0,0,0,0.04)' : 'none' }}
                  onMouseEnter={e => (e.currentTarget.style.background = '#fafafa')}
                  onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}
                >
                  <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: color + '15', fontSize: '1rem' }}>
                    {icon}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span style={{ fontWeight: 500, fontSize: '0.875rem', color: '#0f172a' }}>{tx.description}</span>
                      {tx.isRecurring && <Badge color="#4f46e5">🔄 Recurring</Badge>}
                    </div>
                    <div className="flex items-center gap-2 mt-0.5 flex-wrap">
                      <span style={{ fontSize: '0.75rem', color: '#94a3b8' }}>{tx.category}</span>
                      <span style={{ fontSize: '0.7rem', color: '#cbd5e1' }}>·</span>
                      <span style={{ fontSize: '0.75rem', color: '#94a3b8' }}>{formatDate(tx.date)}</span>
                      <span style={{ fontSize: '0.7rem', color: '#cbd5e1' }}>·</span>
                      <span style={{ fontSize: '0.75rem', color: '#94a3b8' }}>{tx.paymentMethod}</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 flex-shrink-0">
                    <div className="text-right">
                      <div style={{ fontWeight: 700, fontSize: '0.9rem', color: tx.type === 'income' ? '#10b981' : '#0f172a' }}>
                        {tx.type === 'income' ? '+' : '−'}{formatCurrency(tx.amount)}
                      </div>
                    </div>
                    <div className="flex gap-1">
                      <button
                        onClick={() => { setEditTx(tx); setShowModal(true); }}
                        className="w-7 h-7 rounded-lg flex items-center justify-center transition-colors"
                        style={{ color: '#94a3b8' }}
                        onMouseEnter={e => { (e.currentTarget.style.background = '#eef2ff'); (e.currentTarget.style.color = '#4f46e5'); }}
                        onMouseLeave={e => { (e.currentTarget.style.background = 'transparent'); (e.currentTarget.style.color = '#94a3b8'); }}
                      >
                        <Pencil size={13} />
                      </button>
                      <button
                        onClick={() => setConfirmDelete(tx.id)}
                        className="w-7 h-7 rounded-lg flex items-center justify-center transition-colors"
                        style={{ color: '#94a3b8' }}
                        onMouseEnter={e => { (e.currentTarget.style.background = '#fef2f2'); (e.currentTarget.style.color = '#ef4444'); }}
                        onMouseLeave={e => { (e.currentTarget.style.background = 'transparent'); (e.currentTarget.style.color = '#94a3b8'); }}
                      >
                        <Trash2 size={13} />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Transaction Modal */}
      {showModal && (
        <TransactionModal
          user={user}
          transaction={editTx}
          onClose={() => { setShowModal(false); setEditTx(undefined); }}
          onSave={() => { setShowModal(false); setEditTx(undefined); onRefresh(); }}
        />
      )}

      {/* Delete confirmation */}
      {confirmDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/50" onClick={() => setConfirmDelete(null)} />
          <div className="relative rounded-2xl p-6 z-10 w-full max-w-sm" style={{ background: 'white', boxShadow: '0 25px 60px rgba(0,0,0,0.25)' }}>
            <div className="text-center">
              <div style={{ fontSize: '2rem', marginBottom: '8px' }}>🗑️</div>
              <h3 style={{ fontWeight: 700, fontSize: '1rem', color: '#0f172a' }}>Delete Transaction?</h3>
              <p style={{ color: '#64748b', fontSize: '0.875rem', marginTop: '6px' }}>This action cannot be undone.</p>
              <div className="flex gap-3 mt-5">
                <button onClick={() => setConfirmDelete(null)} className="flex-1 py-2.5 rounded-xl" style={{ background: '#f1f5f9', color: '#64748b', fontWeight: 600, fontSize: '0.875rem' }}>Cancel</button>
                <button onClick={() => handleDelete(confirmDelete)} className="flex-1 py-2.5 rounded-xl" style={{ background: '#ef4444', color: 'white', fontWeight: 600, fontSize: '0.875rem' }}>Delete</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
