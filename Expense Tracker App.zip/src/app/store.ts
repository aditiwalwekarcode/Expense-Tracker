import type { User, Transaction, Budget, SavingsGoal, RecurringTemplate, PaymentMethod, TransactionType } from './types';

let _idCounter = 0;
export function generateId(): string {
  return `${Date.now()}_${++_idCounter}_${Math.random().toString(36).substr(2, 5)}`;
}

export function hashPassword(password: string): string {
  // Demo-only hashing — not for production
  return btoa(encodeURIComponent(password + '__et_salt_2026__'));
}

export function verifyPassword(password: string, hash: string): boolean {
  return hashPassword(password) === hash;
}

function makeTransaction(
  userId: string,
  type: TransactionType,
  amount: number,
  category: string,
  date: string,
  description: string,
  paymentMethod: PaymentMethod,
  isRecurring = false
): Transaction {
  return { id: generateId(), userId, type, amount, category, date, description, paymentMethod, isRecurring };
}

function seedDemoData(userId: string): void {
  const t = (
    type: TransactionType, amount: number, category: string, date: string,
    description: string, paymentMethod: PaymentMethod, isRecurring = false
  ) => makeTransaction(userId, type, amount, category, date, description, paymentMethod, isRecurring);

  const transactions: Transaction[] = [
    // ── June 2026 ──
    t('income', 75000, 'Salary', '2026-06-01', 'Monthly salary – June', 'Net Banking', true),
    t('expense', 20000, 'Bills', '2026-06-02', 'Monthly rent', 'UPI', true),
    t('expense', 1199, 'Bills', '2026-06-03', 'JioFiber internet bill', 'UPI', true),
    t('expense', 649, 'Entertainment', '2026-06-03', 'Netflix subscription', 'Card', true),
    t('expense', 1850, 'Food', '2026-06-04', 'Weekly grocery – DMart', 'UPI'),
    t('expense', 450, 'Food', '2026-06-05', 'Office cafeteria lunch', 'UPI'),
    t('expense', 280, 'Travel', '2026-06-05', 'Uber – office commute', 'UPI'),
    t('expense', 3500, 'Shopping', '2026-06-06', 'Amazon – shirt & trousers', 'Card'),
    t('expense', 650, 'Food', '2026-06-07', 'Restaurant dinner with friends', 'UPI'),
    t('expense', 1500, 'Healthcare', '2026-06-08', 'Apollo clinic consultation', 'Card'),
    t('expense', 850, 'Healthcare', '2026-06-08', 'Pharmacy – medicines', 'Cash'),
    t('expense', 320, 'Travel', '2026-06-09', 'Metro monthly pass', 'Card'),
    t('expense', 599, 'Entertainment', '2026-06-10', 'Movie tickets – Avengers', 'UPI'),
    t('expense', 2200, 'Food', '2026-06-11', 'Weekly grocery – Big Basket', 'Card'),
    t('expense', 999, 'Education', '2026-06-12', 'Udemy – React Advanced course', 'Card'),
    t('expense', 480, 'Food', '2026-06-12', 'Zomato dinner order', 'UPI'),
    t('expense', 1500, 'Bills', '2026-06-13', 'BSES electricity bill', 'UPI'),
    t('expense', 250, 'Travel', '2026-06-14', 'Rapido – weekend outing', 'UPI'),
    t('income', 12000, 'Freelancing', '2026-06-15', 'Website project payment', 'Net Banking'),
    t('expense', 1800, 'Food', '2026-06-15', 'Big Basket weekly grocery', 'Card'),
    t('expense', 2999, 'Shopping', '2026-06-16', 'Myntra – summer collection', 'Card'),
    t('expense', 350, 'Food', '2026-06-16', 'Swiggy breakfast order', 'UPI'),
    t('expense', 190, 'Travel', '2026-06-17', 'Uber – client meeting', 'UPI'),

    // ── May 2026 ──
    t('income', 75000, 'Salary', '2026-05-01', 'Monthly salary – May', 'Net Banking', true),
    t('expense', 20000, 'Bills', '2026-05-02', 'Monthly rent', 'UPI', true),
    t('expense', 1199, 'Bills', '2026-05-03', 'JioFiber internet bill', 'UPI', true),
    t('expense', 649, 'Entertainment', '2026-05-03', 'Netflix subscription', 'Card', true),
    t('expense', 5200, 'Travel', '2026-05-05', 'Train tickets – Mumbai trip', 'Card'),
    t('expense', 3800, 'Shopping', '2026-05-07', 'Sony WH-1000XM5 earbuds', 'Card'),
    t('expense', 1650, 'Food', '2026-05-08', 'Weekly grocery shopping', 'UPI'),
    t('expense', 890, 'Food', '2026-05-10', 'Birthday dinner – The Fatty Bao', 'Card'),
    t('expense', 1500, 'Bills', '2026-05-12', 'Electricity bill', 'UPI'),
    t('income', 5000, 'Gifts', '2026-05-15', 'Birthday gift from family', 'Cash'),
    t('expense', 2100, 'Food', '2026-05-15', 'Monthly grocery stock-up', 'Card'),
    t('expense', 450, 'Entertainment', '2026-05-18', 'Movie – Inception remaster', 'UPI'),
    t('expense', 299, 'Education', '2026-05-20', 'Book – Clean Code (O\'Reilly)', 'UPI'),
    t('expense', 780, 'Travel', '2026-05-22', 'Uber rides – various trips', 'UPI'),
    t('expense', 1950, 'Food', '2026-05-25', 'Weekly grocery', 'UPI'),
    t('expense', 550, 'Healthcare', '2026-05-27', 'Pharmacy – vitamins & supplements', 'Cash'),
    t('expense', 1200, 'Shopping', '2026-05-29', 'Amazon – household items', 'Card'),

    // ── April 2026 ──
    t('income', 75000, 'Salary', '2026-04-01', 'Monthly salary – April', 'Net Banking', true),
    t('expense', 20000, 'Bills', '2026-04-02', 'Monthly rent', 'UPI', true),
    t('expense', 1199, 'Bills', '2026-04-03', 'JioFiber internet bill', 'UPI', true),
    t('expense', 649, 'Entertainment', '2026-04-03', 'Netflix subscription', 'Card', true),
    t('expense', 1750, 'Food', '2026-04-05', 'Weekly grocery shopping', 'UPI'),
    t('expense', 1200, 'Bills', '2026-04-08', 'Electricity bill', 'UPI'),
    t('expense', 2800, 'Shopping', '2026-04-10', 'Flipkart Big Sale – shoes & belt', 'Card'),
    t('income', 8000, 'Freelancing', '2026-04-12', 'Logo & branding project', 'UPI'),
    t('expense', 950, 'Food', '2026-04-13', 'Café lunch + coffee', 'UPI'),
    t('expense', 1900, 'Food', '2026-04-17', 'Weekly grocery', 'Card'),
    t('expense', 3200, 'Travel', '2026-04-19', 'IndiGo flights – Goa', 'Card'),
    t('expense', 4500, 'Travel', '2026-04-20', 'Hotel – Goa 2 nights', 'Card'),
    t('expense', 1200, 'Entertainment', '2026-04-21', 'Water sports – Calangute Beach', 'Cash'),
    t('expense', 850, 'Food', '2026-04-22', 'Seafood dinner – Goa', 'Cash'),
    t('expense', 599, 'Education', '2026-04-25', 'Coursera Data Science cert', 'Card'),
    t('expense', 2000, 'Food', '2026-04-28', 'Monthly grocery stock-up', 'UPI'),
    t('expense', 650, 'Healthcare', '2026-04-29', 'Pharmacy – vitamins', 'Cash'),
  ];

  const budget: Budget = {
    monthly: 50000,
    categories: {
      Food: 12000,
      Travel: 5000,
      Shopping: 8000,
      Entertainment: 2000,
      Education: 2000,
      Bills: 25000,
      Healthcare: 3000,
      Other: 2000,
    },
  };

  const savings: SavingsGoal[] = [
    { id: generateId(), userId, name: 'Emergency Fund', targetAmount: 150000, currentAmount: 75000, targetDate: '2026-12-31', description: '6 months of living expenses as emergency buffer' },
    { id: generateId(), userId, name: 'New MacBook Pro', targetAmount: 80000, currentAmount: 35000, targetDate: '2026-09-30', description: 'M4 MacBook Pro for work and side projects' },
    { id: generateId(), userId, name: 'Europe Vacation', targetAmount: 200000, currentAmount: 45000, targetDate: '2027-06-01', description: 'Dream trip to France, Italy & Spain' },
  ];

  const recurring: RecurringTemplate[] = [
    { id: generateId(), userId, type: 'income', amount: 75000, category: 'Salary', description: 'Monthly Salary', paymentMethod: 'Net Banking', frequency: 'monthly', nextDueDate: '2026-07-01', isActive: true },
    { id: generateId(), userId, type: 'expense', amount: 20000, category: 'Bills', description: 'Monthly Rent', paymentMethod: 'UPI', frequency: 'monthly', nextDueDate: '2026-07-02', isActive: true },
    { id: generateId(), userId, type: 'expense', amount: 649, category: 'Entertainment', description: 'Netflix Subscription', paymentMethod: 'Card', frequency: 'monthly', nextDueDate: '2026-07-03', isActive: true },
    { id: generateId(), userId, type: 'expense', amount: 1199, category: 'Bills', description: 'JioFiber Internet', paymentMethod: 'UPI', frequency: 'monthly', nextDueDate: '2026-07-03', isActive: true },
    { id: generateId(), userId, type: 'expense', amount: 1500, category: 'Healthcare', description: 'Gym Membership', paymentMethod: 'Card', frequency: 'monthly', nextDueDate: '2026-07-05', isActive: true },
    { id: generateId(), userId, type: 'expense', amount: 999, category: 'Entertainment', description: 'Spotify Premium Family', paymentMethod: 'Card', frequency: 'monthly', nextDueDate: '2026-07-10', isActive: false },
  ];

  const existing: Transaction[] = JSON.parse(localStorage.getItem('et_transactions') || '[]');
  localStorage.setItem('et_transactions', JSON.stringify([...existing.filter(x => x.userId !== userId), ...transactions]));
  localStorage.setItem(`et_budget_${userId}`, JSON.stringify(budget));

  const existingSavings: SavingsGoal[] = JSON.parse(localStorage.getItem('et_savings') || '[]');
  localStorage.setItem('et_savings', JSON.stringify([...existingSavings.filter(x => x.userId !== userId), ...savings]));

  const existingRecurring: RecurringTemplate[] = JSON.parse(localStorage.getItem('et_recurring') || '[]');
  localStorage.setItem('et_recurring', JSON.stringify([...existingRecurring.filter(x => x.userId !== userId), ...recurring]));
}

// ── Users ──────────────────────────────────────────────────────

export function getUsers(): User[] {
  return JSON.parse(localStorage.getItem('et_users') || '[]');
}

function saveUser(user: User): void {
  const users = getUsers();
  const idx = users.findIndex(u => u.id === user.id);
  if (idx >= 0) users[idx] = user;
  else users.push(user);
  localStorage.setItem('et_users', JSON.stringify(users));
}

export function initializeDemoUser(): void {
  const users = getUsers();
  if (!users.find(u => u.email === 'demo@example.com')) {
    const demo: User = { id: 'demo_user_001', name: 'Arjun Sharma', email: 'demo@example.com', passwordHash: hashPassword('demo123') };
    saveUser(demo);
    seedDemoData(demo.id);
  }
}

export function registerUser(name: string, email: string, password: string): User | string {
  const users = getUsers();
  if (users.find(u => u.email.toLowerCase() === email.toLowerCase())) return 'Email already registered.';
  const user: User = { id: generateId(), name, email: email.toLowerCase(), passwordHash: hashPassword(password) };
  saveUser(user);
  return user;
}

export function loginUser(email: string, password: string): User | string {
  const users = getUsers();
  const user = users.find(u => u.email.toLowerCase() === email.toLowerCase());
  if (!user) return 'No account found with this email.';
  if (!verifyPassword(password, user.passwordHash)) return 'Incorrect password.';
  return user;
}

export function getCurrentUser(): User | null {
  const id = localStorage.getItem('et_current_user');
  if (!id) return null;
  return getUsers().find(u => u.id === id) || null;
}

export function setCurrentUser(user: User | null): void {
  if (user) localStorage.setItem('et_current_user', user.id);
  else localStorage.removeItem('et_current_user');
}

// ── Transactions ───────────────────────────────────────────────

export function getTransactions(userId: string): Transaction[] {
  const all: Transaction[] = JSON.parse(localStorage.getItem('et_transactions') || '[]');
  return all.filter(t => t.userId === userId).sort((a, b) => b.date.localeCompare(a.date));
}

export function saveTransaction(tx: Transaction): void {
  const all: Transaction[] = JSON.parse(localStorage.getItem('et_transactions') || '[]');
  const idx = all.findIndex(t => t.id === tx.id);
  if (idx >= 0) all[idx] = tx;
  else all.push(tx);
  localStorage.setItem('et_transactions', JSON.stringify(all));
}

export function deleteTransaction(id: string): void {
  const all: Transaction[] = JSON.parse(localStorage.getItem('et_transactions') || '[]');
  localStorage.setItem('et_transactions', JSON.stringify(all.filter(t => t.id !== id)));
}

// ── Budget ─────────────────────────────────────────────────────

export function getBudget(userId: string): Budget {
  const raw = localStorage.getItem(`et_budget_${userId}`);
  return raw ? JSON.parse(raw) : { monthly: 0, categories: {} };
}

export function saveBudget(userId: string, budget: Budget): void {
  localStorage.setItem(`et_budget_${userId}`, JSON.stringify(budget));
}

// ── Savings Goals ──────────────────────────────────────────────

export function getSavingsGoals(userId: string): SavingsGoal[] {
  const all: SavingsGoal[] = JSON.parse(localStorage.getItem('et_savings') || '[]');
  return all.filter(g => g.userId === userId);
}

export function saveSavingsGoal(goal: SavingsGoal): void {
  const all: SavingsGoal[] = JSON.parse(localStorage.getItem('et_savings') || '[]');
  const idx = all.findIndex(g => g.id === goal.id);
  if (idx >= 0) all[idx] = goal;
  else all.push(goal);
  localStorage.setItem('et_savings', JSON.stringify(all));
}

export function deleteSavingsGoal(id: string): void {
  const all: SavingsGoal[] = JSON.parse(localStorage.getItem('et_savings') || '[]');
  localStorage.setItem('et_savings', JSON.stringify(all.filter(g => g.id !== id)));
}

// ── Recurring Templates ────────────────────────────────────────

export function getRecurringTemplates(userId: string): RecurringTemplate[] {
  const all: RecurringTemplate[] = JSON.parse(localStorage.getItem('et_recurring') || '[]');
  return all.filter(r => r.userId === userId);
}

export function saveRecurringTemplate(tpl: RecurringTemplate): void {
  const all: RecurringTemplate[] = JSON.parse(localStorage.getItem('et_recurring') || '[]');
  const idx = all.findIndex(r => r.id === tpl.id);
  if (idx >= 0) all[idx] = tpl;
  else all.push(tpl);
  localStorage.setItem('et_recurring', JSON.stringify(all));
}

export function deleteRecurringTemplate(id: string): void {
  const all: RecurringTemplate[] = JSON.parse(localStorage.getItem('et_recurring') || '[]');
  localStorage.setItem('et_recurring', JSON.stringify(all.filter(r => r.id !== id)));
}
