export type PaymentMethod = 'Cash' | 'UPI' | 'Card' | 'Net Banking' | 'Other';
export type TransactionType = 'expense' | 'income';
export type RecurringFrequency = 'daily' | 'weekly' | 'monthly' | 'yearly';
export type NavSection = 'dashboard' | 'transactions' | 'budget' | 'analytics' | 'savings' | 'recurring';

export const EXPENSE_CATEGORIES = ['Food', 'Travel', 'Shopping', 'Entertainment', 'Education', 'Bills', 'Healthcare', 'Other'];
export const INCOME_CATEGORIES = ['Salary', 'Pocket Money', 'Freelancing', 'Gifts', 'Other'];
export const PAYMENT_METHODS: PaymentMethod[] = ['Cash', 'UPI', 'Card', 'Net Banking', 'Other'];

export const CATEGORY_COLORS: Record<string, string> = {
  Food: '#f59e0b',
  Travel: '#3b82f6',
  Shopping: '#ec4899',
  Entertainment: '#8b5cf6',
  Education: '#06b6d4',
  Bills: '#64748b',
  Healthcare: '#ef4444',
  Other: '#94a3b8',
  Salary: '#10b981',
  'Pocket Money': '#34d399',
  Freelancing: '#059669',
  Gifts: '#a78bfa',
};

export const CATEGORY_ICONS: Record<string, string> = {
  Food: '🍽️',
  Travel: '✈️',
  Shopping: '🛍️',
  Entertainment: '🎬',
  Education: '📚',
  Bills: '🧾',
  Healthcare: '🏥',
  Other: '📦',
  Salary: '💼',
  'Pocket Money': '💵',
  Freelancing: '💻',
  Gifts: '🎁',
};

export interface User {
  id: string;
  name: string;
  email: string;
  passwordHash: string;
}

export interface Transaction {
  id: string;
  userId: string;
  type: TransactionType;
  amount: number;
  category: string;
  date: string;
  description: string;
  paymentMethod: PaymentMethod;
  isRecurring: boolean;
}

export interface RecurringTemplate {
  id: string;
  userId: string;
  type: TransactionType;
  amount: number;
  category: string;
  description: string;
  paymentMethod: PaymentMethod;
  frequency: RecurringFrequency;
  nextDueDate: string;
  isActive: boolean;
}

export interface Budget {
  monthly: number;
  categories: Record<string, number>;
}

export interface SavingsGoal {
  id: string;
  userId: string;
  name: string;
  targetAmount: number;
  currentAmount: number;
  targetDate: string;
  description: string;
}

export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0,
  }).format(amount);
}

export function formatDate(dateStr: string): string {
  return new Date(dateStr + 'T00:00:00').toLocaleDateString('en-IN', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  });
}

export function getCurrentMonthRange(): { start: string; end: string } {
  const now = new Date();
  const start = new Date(now.getFullYear(), now.getMonth(), 1);
  const end = new Date(now.getFullYear(), now.getMonth() + 1, 0);
  return {
    start: start.toISOString().split('T')[0],
    end: end.toISOString().split('T')[0],
  };
}

export function getPreviousMonthRange(): { start: string; end: string } {
  const now = new Date();
  const start = new Date(now.getFullYear(), now.getMonth() - 1, 1);
  const end = new Date(now.getFullYear(), now.getMonth(), 0);
  return {
    start: start.toISOString().split('T')[0],
    end: end.toISOString().split('T')[0],
  };
}
